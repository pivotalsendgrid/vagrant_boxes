default['sendgrid_package_repo']['setuptools_version'] = '1.1.6'

default['sendgrid_package_repo']['repos']['available'] = [:local, :staging, :production]
default['sendgrid_package_repo']['repos']['enabled'] = if node.chef_environment == 'ci'
  [:local]
else
  # NOTE: order will determine pypi search order
  [:local, :production]
end

# local repos
default['sendgrid_package_repo']['local']['yum']['incoming'] = '/tmp/ci-repo'
default['sendgrid_package_repo']['local']['yum']['path'] = '/tmp/repos/local-yum'
default['sendgrid_package_repo']['local']['yum']['url'] = 'file:///tmp/repos/local-yum'
default['sendgrid_package_repo']['local']['yum']['priority'] = '50'
default['sendgrid_package_repo']['local']['yum']['gpgcheck'] = false
default['sendgrid_package_repo']['local']['yum']['description'] = 'SendGrid local application repository for CI and development builds'

default['sendgrid_package_repo']['local']['pypi']['incoming'] = '/tmp/ci-repo'
default['sendgrid_package_repo']['local']['pypi']['path'] = '/tmp/repos/local-pypi'
default['sendgrid_package_repo']['local']['pypi']['url'] = 'http://localhost:8989/simple/'

# staging repos
default['sendgrid_package_repo']['staging']['yum']['incoming'] = nil
default['sendgrid_package_repo']['staging']['yum']['path'] = nil
default['sendgrid_package_repo']['staging']['yum']['url'] = 'http://repo.sjc1.sendgrid.net/yum/sendgrid/staging/$releasever/$basearch/'
default['sendgrid_package_repo']['staging']['yum']['priority'] = '51'
default['sendgrid_package_repo']['staging']['yum']['gpgcheck'] = false
default['sendgrid_package_repo']['staging']['yum']['description'] = 'SendGrid application repository (stage)'

default['sendgrid_package_repo']['staging']['pypi']['incoming'] = nil
default['sendgrid_package_repo']['staging']['pypi']['path'] = nil
default['sendgrid_package_repo']['staging']['pypi']['url'] = 'http://pypi.strepo.sjc1.sendgrid.net/simple/'

# prod repos
default['sendgrid_package_repo']['production']['yum']['incoming'] = nil
default['sendgrid_package_repo']['production']['yum']['path'] = nil
default['sendgrid_package_repo']['production']['yum']['url'] = 'http://repo.sjc1.sendgrid.net/yum/sendgrid/production/$releasever/$basearch/'
default['sendgrid_package_repo']['production']['yum']['priority'] = '51'
default['sendgrid_package_repo']['production']['yum']['gpgcheck'] = false
default['sendgrid_package_repo']['production']['yum']['description'] = 'SendGrid application repository (production)'

default['sendgrid_package_repo']['production']['pypi']['incoming'] = nil
default['sendgrid_package_repo']['production']['pypi']['path'] = nil
default['sendgrid_package_repo']['production']['pypi']['url'] = 'http://pypi.repo.sjc1.sendgrid.net/simple/'
