# TODO Figure out how to use notifies to only run things when applicable
action :create do
  name = new_resource.name
  incoming = new_resource.incoming
  url = new_resource.url
  path = new_resource.path

  directory path do
    recursive true
  end

  # Process incoming eggs and possible trigger LWRP update notification.
  # NOTE: do not have to notify pypi server to restart when processing
  # new incoming pips.  Just need to copy them into place.
  ruby_block "process #{incoming}" do
    block do
      Dir["#{incoming}/**/*.egg", "#{incoming}/**/*.tar.gz"].each do |file|
        cp = Chef::Resource::Execute.new("copy '#{file}'", @run_context)
        cp.cwd path
        cp.command "cp -a #{file} ."
        cp.run_action(:run)
        new_resource.updated_by_last_action(cp.updated_by_last_action?)
      end
    end
  end

  # Create pypi root
  pypi_root = "/opt/pypiserver"
  directory pypi_root

  # Create virtualenv
  venv = "#{pypi_root}/venv"
  python_virtualenv venv

  # Install pipserver into virtualenv
  python_pip "pypiserver" do
    virtualenv venv
    notifies :restart, "sendgrid_upstart_service[#{name}]"
  end

  # Create local pypi server upstart job
  sendgrid_upstart_job name do
    start_command "#{venv}/bin/pypi-server -p #{URI(url).port} #{path}"
    respawn true
    notifies :restart, "sendgrid_upstart_service[#{name}]"
  end

  # Start pypiserver upstart job
  sendgrid_upstart_service name do
    action :start
  end

end
