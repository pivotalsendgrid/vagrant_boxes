# TODO Figure out how to use notifies to only run things when applicable
action :create do
  name = new_resource.name
  incoming = new_resource.incoming
  repo_path = new_resource.repo_path || ::File.join('/tmp/repos', new_resource.name)

  package 'createrepo'

  directory repo_path do
    mode 00755
    recursive true
  end

  # Process incoming rpms and possible trigger LWRP update notification.
  # NOTE: must notify createrepo to run when new rpms found in incoming.
  ruby_block "process #{incoming}" do
    block do
      Dir["#{incoming}/**/*.rpm"].each do |file|
        # TODO This is what should trigger updated, figure out how to only
        # trigger if we actually change packages
        cp = Chef::Resource::Execute.new("copy '#{file}'", @run_context)
        cp.cwd repo_path
        cp.command "cp #{file} ."
        cp.run_action(:run)
        cp.notifies(:run, "execute[createrepo-#{name}]")
        new_resource.updated_by_last_action(cp.updated_by_last_action?)
      end
    end
  end

  # Should we use shell_out here to not always notify?
  # Or maybe action: nothing and rely copy above to
  # notify execute to run?
  execute "createrepo-#{name}" do
    cwd repo_path
    command "createrepo ."
    #action :nothin
  end
end
