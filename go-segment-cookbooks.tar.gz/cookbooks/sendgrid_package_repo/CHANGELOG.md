# CHANGELOG

## 3.3.3
- Set pypi repos env var in chef run env.  Allows
- other chef resources (aka pip) to have access to them.

## 3.3.2
- Do not guard creating local repos with checking existing incoming package dir.
- Fixed tests to use shell_out so /etc/profile.d/pip.sh will be sourced on each
  chef run.
- Run yum makecache if DEPLOY=1 or in ci or _defualt chef environment.

## 3.3.1
- Pin setup tools to 1.1.6
- Fix pypi tests

## 3.3.0
- Removed ubuntu code
- Refactored cookbook recipes to be based upon functionality rather
  than linux distro (_centos,_ubuntu => _yum, _pypp)
- Added support for pypi servers
- Added support to start local pypi server in ci chef environment
- Fixed bug where production yum repo was enabled in ci chef environment
- Added pypi_local LWRP.

## 3.2.0

- Update to v3.x of the yum cookbook
- Remove environment-based logic in favor of a list of repositories in an
attribute that can be overridden at the environment level
- Refactored tests

## 3.1.2

- Change location of package repo (use CNAME)

## 3.1.1

- Action remove not delete. :(

## 3.1.0

- Delete delete cobbler default repo.

## 3.0.8
- Update the repo URL attribs to use one FWDN attrib and have that point to the SJC CNAME

## 3.0.7

- Update repository URLs and make sure Chef keeps them up to date.

## 3.0.6

- Update URL of internal package repo

## 3.0.5

- Fix staging regexp to include existing, legacy environment names.

## 3.0.4

- Fix test to only check for local repo if local incoming exists.
- Fix regexp matches to be correct for staging, and also more robust.

## 3.0.3

- Fix more typos. There are no such environments called "development,"
"staging," or "production"

## 3.0.2
- _centos recipe was not matching any of the environments we actually have in
chef 10. Changed to regex for them to match

## 3.0.0
- Implement new repository association and priorities for build pipeline.
- Always run 'yum makecache' to pickup any package changes after we've added a
repository.

## 2.1.5

- Fix for "Repository 'foo' is missing name in configuration, using id"

## 2.1.4

- Only configure the package repo if the server is available

## 2.1.3

- Fix bug with LWRP notification bubbling, only trigger notification when we
change packages in repo

## 2.1.2

- Fixup dists/#{codename} directory creation when no files installed
- Fix notifications

## 2.1.1

- Move CentOS and Ubuntu stuff to their own recipes to stop failing tests

## 2.1.0

- Add `local` LWRP for creating local repos (infrastructure team)

## 2.0.5

- Relax dependencies

## 2.0.4

- Bugfix the missing 'w' that ate my day

## 2.0.3

- Configure SendGrid repositories

## 2.0.2

- Update apt and yum dependencies again

## 2.0.1

- Update apt and yum dependencies

## 2.0.0

- Move all server stuff into `sendgrid_package_repo_server`

## 1.0.3

- Remove include of minitest-handler (Oops!)

## 1.0.2

- Remove dependency on minitest-handler

## 1.0.0

- Rename `default` recipe to `server`
- Add new `default` recipe for configuring clients
- Remove dependency on `sendgrid`
- Add `apt`, `minitest-handler`, and `yum` dependencies

## 0.1.0

- Initial release
