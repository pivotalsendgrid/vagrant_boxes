name             "sendgrid_package_repo"
maintainer       "SendGrid"
maintainer_email "operations@sendgrid.com"
license          "All rights reserved"
description      "Installs/Configures sendgrid_package_repo"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '3.3.3'

depends          'apt', '~> 2.2'
depends          'yum', '~> 3.1'
depends          'yum-epel', '~> 0.3'
depends          'python', '~> 1.4'
depends          'sendgrid_upstart', '~> 1.1'
