#
# Cookbook Name:: sendgrid_package_repo
# Recipe:: _common
#
# Copyright (C) 2013 SendGrid
#
# All rights reserved - Do Not Redistribute
#
repos_available = node['sendgrid_package_repo']['repos']['available']
repos_enabled = node['sendgrid_package_repo']['repos']['enabled'].map(&:to_sym)
invalid_repos = repos_enabled.find_all { |obj| !repos_available.include?(obj) }

unless invalid_repos.empty?
  Chef::Application.fatal!("Invalid repos specified: #{invalid_repos.join(', ')}")
end
