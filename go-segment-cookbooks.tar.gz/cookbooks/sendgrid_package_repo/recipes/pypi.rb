#
# Cookbook Name:: sendgrid_package_repo
# Recipe:: pypi
#
# Copyright (C) 2013 SendGrid
#
# All rights reserved - Do Not Redistribute
#
include_recipe "#{cookbook_name}::_common"

repos_enabled = node['sendgrid_package_repo']['repos']['enabled'].map(&:to_sym)

if repos_enabled.include?(:local)
  package 'libffi-devel'
  node.default['python']['setuptools_version'] = node['sendgrid_package_repo']['setuptools_version']
  include_recipe 'python'

  local = node['sendgrid_package_repo']['local']['pypi']
  sendgrid_package_repo_local_pypi 'local-pypi' do
    incoming local['incoming']
    url local['url']
    path local['path']
  end
end

repo_urls = repos_enabled.map do |repo|
  node['sendgrid_package_repo'][repo]['pypi']['url']
end

# Write pypi repo urls to environment variable to be sourced
template "/etc/profile.d/pip.sh" do
  source 'pip.sh.erb'
  user  'root'
  group 'root'
  mode  00644
  action :create
  variables({ :extra_index_urls => repo_urls })
end

# Add the enabled pypi repos to this chef run environment
ENV['PIP_EXTRA_INDEX_URL'] = repo_urls.join(' ')
