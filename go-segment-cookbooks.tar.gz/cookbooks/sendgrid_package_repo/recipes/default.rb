#
# Cookbook Name:: sendgrid_package_repo
# Recipe:: default
#
# Copyright (C) 2013 SendGrid
#
# All rights reserved - Do Not Redistribute
#
include_recipe "#{cookbook_name}::yum"
include_recipe "#{cookbook_name}::pypi"
