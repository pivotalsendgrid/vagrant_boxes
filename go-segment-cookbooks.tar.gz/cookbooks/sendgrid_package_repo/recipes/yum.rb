#
# Cookbook Name:: sendgrid_package_repo
# Recipe:: yum
#
# Copyright (C) 2013 SendGrid
#
# All rights reserved - Do Not Redistribute
#
include_recipe "#{cookbook_name}::_common"
include_recipe 'yum-epel'

# Enable priorities so we can put local ahead of production/staging
package 'yum-plugin-priorities'

# Set 15 min yum cache
yum_globalconfig '/etc/yum.conf' do
  metadata_expire '15m'
end

# Always delete the cobbler default repo
yum_repository "cobbler-config" do
  action :remove
end

repos_enabled = node['sendgrid_package_repo']['repos']['enabled'].map(&:to_sym)

if repos_enabled.include?(:local)
  local = node['sendgrid_package_repo']['local']['yum']

  sendgrid_package_repo_local 'local-yum' do
    incoming local['incoming']
    repo_path local['path']
  end
end

repos_enabled.each do |repo|
  yum = node['sendgrid_package_repo'][repo]['yum']

  # Create yum repo
  yum_repository "sendgrid-#{repo}" do #~FC022
    description yum['description']
    baseurl yum['url']
    gpgcheck yum['gpgcheck']
    priority yum['priority']
  end
end

repos_available = node['sendgrid_package_repo']['repos']['available']
(repos_available - repos_enabled).each do |repo|
  yum_repository "sendgrid-#{repo}" do
    action :delete
  end
end

# Always create yum cache if deploying
# TODO: refactor this guard to be common method deploy_run?
execute 'yum makecache' do
  only_if { %w{ci _default}.include?(node.chef_environment) || ENV['DEPLOY'] == '1' }
end
