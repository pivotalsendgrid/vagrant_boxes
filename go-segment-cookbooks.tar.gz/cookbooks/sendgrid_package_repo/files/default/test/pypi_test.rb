describe_recipe 'sendgrid_package_repo::pypi' do
  require 'chef/mixin/shell_out'
  include Chef::Mixin::ShellOut

  it 'configures the SendGrid pypi repositories' do
    repos_installed = shell_out!("echo $PIP_EXTRA_INDEX_URL").stdout.split(' ')
    repos_available = node['sendgrid_package_repo']['repos']['available'].map do |repo|
      node['sendgrid_package_repo'][repo]['pypi']['url']
    end
    repos_enabled = node['sendgrid_package_repo']['repos']['enabled'].map(&:to_sym).map do |repo|
      node['sendgrid_package_repo'][repo]['pypi']['url']
    end
    repos_disabled = repos_available - repos_enabled

    # Assert enabled repos are installed
    repos_enabled.each do |repo|
      assert_includes(repos_installed, repo, "An enabled pypi repo failed to be installed: #{repo}")
    end

    # Assert disabled repos are not installed
    repos_disabled.each do |repo|
      refute_includes(repos_installed, repo, "A disabled pypi repo was incorrectly installed: #{repo}")
    end
  end
end
