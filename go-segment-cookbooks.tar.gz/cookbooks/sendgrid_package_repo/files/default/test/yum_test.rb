describe_recipe 'sendgrid_package_repo::yum' do
  require 'chef/mixin/shell_out'
  include Chef::Mixin::ShellOut

  it 'configures the SendGrid yum repositories' do
    repolist = shell_out!("yum repolist").stdout
    repos_available = node['sendgrid_package_repo']['repos']['available']
    repos_enabled = node['sendgrid_package_repo']['repos']['enabled'].map(&:to_sym)

    repos_enabled.each do |repo|
      repolist.must_match(/sendgrid-#{repo}/)
    end
    (repos_available - repos_enabled).each do |repo|
      repolist.wont_match(/sendgrid-#{repo}/)
    end
  end
end
