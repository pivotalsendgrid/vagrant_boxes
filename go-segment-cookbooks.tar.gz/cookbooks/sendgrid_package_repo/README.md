# sendgrid_package_repo cookbook

This cookbook configures package repositories on clients.

## Usage

Just add the default recipe to your run list.
