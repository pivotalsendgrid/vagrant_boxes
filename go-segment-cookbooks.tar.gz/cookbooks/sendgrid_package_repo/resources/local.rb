actions :create
default_action :create

attribute :name, :kind_of => String, :name_attribute => true
attribute :incoming, :kind_of => String, :default => nil
attribute :repo_path, :kind_of => String, :default => nil
