include Chef::SendgridApplication::Helpers
include Chef::SendgridApplicationPython::Helpers

use_inline_resources

action :create do
  name = new_resource.name
  application_name = new_resource.application_name || name
  application_mode = new_resource.application_mode
  virtualenv = virtualenv_path(application_name, application_mode) if new_resource.virtualenv_enabled
  start_command = virtualenv_activation_wrapper(virtualenv, new_resource.start_command)

  sendgrid_application_upstart_job name do
    start_command start_command
    application_name application_name
    application_mode application_mode
    user new_resource.user
    environment new_resource.environment
    log_format new_resource.log_format
    start_on new_resource.start_on
    stop_on new_resource.stop_on
  end
end

action :delete do
  name = new_resource.name
  application_name = new_resource.application_name || name
  sendgrid_application_upstart_job application_name do
    action :delete
  end
end
