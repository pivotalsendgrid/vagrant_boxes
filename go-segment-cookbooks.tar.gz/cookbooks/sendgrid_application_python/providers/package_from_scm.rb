include Chef::SendgridApplication::Helpers
include Chef::SendgridApplicationPython::Helpers

use_inline_resources # Trigger notification on any notification from underlying resources

action :install do
  application = new_resource.name
  virtualenv_enabled = new_resource.virtualenv_enabled
  daemon_start_command = new_resource.daemon_start_command
  mode = :deployment
  virtualenv = virtualenv_path(application, mode) if virtualenv_enabled
  daemon_start_command = virtualenv_activation_wrapper(virtualenv, daemon_start_command)

  # Clone from scm, install OS dependencies, setup daemon
  sendgrid_application_package_from_scm application do
    repository new_resource.repository
    revision new_resource.revision
    daemon_start_command daemon_start_command
    daemon_user new_resource.daemon_user
  end

  # Install dependencies
  sendgrid_application_python_dependencies application do
    mode mode
    virtualenv_enabled virtualenv_enabled
    virtualenv_options new_resource.virtualenv_options
  end
end
