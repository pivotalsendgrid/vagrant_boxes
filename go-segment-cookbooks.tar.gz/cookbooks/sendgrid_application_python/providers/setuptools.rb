include Chef::SendgridApplicationPython::Helpers

use_inline_resources # Trigger notification on any notification from underlying resources

[:install, :build, :develop].each do |action|
  action action do
    setup_py = new_resource.setup_py
    virtualenv = new_resource.virtualenv
    command = "python #{setup_py} #{action} #{new_resource.options}"
    command = virtualenv_activation_wrapper(virtualenv, command)
    execute command do
      cwd ::File.dirname(setup_py)
      user virtualenv ? new_resource.user : 'root'
      group virtualenv ? new_resource.group : 'root'
      timeout new_resource.timeout ? new_resource.timeout : 3600 # Default from execute
      only_if { ::File.exists?(setup_py) }
    end
  end
end
