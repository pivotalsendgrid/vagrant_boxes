require 'chef/mixin/shell_out'
require 'chef/mixin/language'

include Chef::Mixin::ShellOut
include Chef::SendgridApplicationPython::Helpers

action :install do
  if ::File.exists?(new_resource.requirements_txt)
    user = new_resource.virtualenv ? new_resource.user : 'root'
    group = new_resource.virtualenv ? new_resource.group : 'root'
    timeout = new_resource.timeout ? new_resource.timeout : 600 # Default from shell_out
    command = "pip install -r #{new_resource.requirements_txt} #{new_resource.options}"

    # Prefixing PIP_CONFIG_FILE is a workaround until pybundler is working correctly
    pip_config_file = "#{::File.dirname(new_resource.requirements_txt)}/.pip/pip.conf"
    command.prepend("PIP_CONFIG_FILE=#{pip_config_file} ") if ::File.exists?(pip_config_file)

    command = virtualenv_activation_wrapper(new_resource.virtualenv, command)

    # Install pip from requirements file
    # Set home environment before shelling out
    environment = Hash.new
    environment['HOME'] = Dir.home(user)
    options = { :user => user, :group => group, :timeout => timeout, :environment => environment }
    pip = shell_out!(command, options)

    # If pip command passes and only has 'Requirement already satisfied' or 'Cleaning up' output
    # then do not notify, else a new pip was install and do notify.
    install_output = pip.stdout.gsub(/(^Requirement already satisfied.*$)/, '').gsub(/(^Cleaning up\.\.\.$)/, '').strip
    install_output.empty? || Chef::Log.info("Installed one or more pips from #{new_resource.requirements_txt}")
    new_resource.updated_by_last_action(!install_output.empty?)
  else
    Chef::Log.info("Missing #{new_resource.requirements_txt} file. Skipping pip install")
    new_resource.updated_by_last_action(false)
  end
end
