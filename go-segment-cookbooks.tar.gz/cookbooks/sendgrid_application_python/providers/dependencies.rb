include Chef::SendgridApplication::Helpers
include Chef::SendgridApplicationPython::Helpers
Chef::Resource.send(:include, Chef::SendgridApplication::Helpers)
Chef::Resource.send(:include, Chef::SendgridApplicationPython::Helpers)

use_inline_resources # Trigger notification on any notification from underlying resources

action :install do
  application = new_resource.application
  virtualenv_enabled = new_resource.virtualenv_enabled
  virtualenv_options = new_resource.virtualenv_options
  timeout = new_resource.timeout ? new_resource.timeout : 600 # Default from shell_out
  mode = new_resource.mode

  application_path = sendgrid_application_path(application, mode, 'current')
  application_user = sendgrid_application_user(mode)
  application_group = sendgrid_application_group(mode)
  project_yml = "#{application_path}/#{PROJECT_YML_BASENAME}"
  virtualenv = virtualenv_path(application, mode) if virtualenv_enabled
  python_version_file = "#{application_path}/#{PYTHON_VERSION_BASENAME}"
  pip_install_lock = "#{application_path}/#{PIP_INSTALL_LOCK_BASENAME}"
  requirements_txt = "#{application_path}/#{REQUIREMENTS_TXT_BASENAME}"
  setup_py = "#{application_path}/#{SETUP_PY_BASENAME}"

  # Errno::EPERM is thrown when attempting to chown files on remote filesystems
  application_path_is_nfs_mount = path_is_nfs_mount(application_path)

  # Drop in python version file with default if missing
  file python_version_file do
    action :create_if_missing
    content "#{node['sendgrid_application_python'][mode]['default_python_version']}\n"
    owner application_user unless application_path_is_nfs_mount
    group application_group unless application_path_is_nfs_mount
    mode 00644
  end

  # Install desired python version based upon project
  sendgrid_application_package "#{application}-install-python" do
    package_name lazy { python_package_name_from(version_from(python_version_file)) }
  end

  # Install OS dependencies
  sendgrid_application_yml_dependencies project_yml do
    resolver Chef::Resource::SendgridApplicationPackage
    yml_keys project_yml_os_dependencies_keys
  end

  # Create virtualenv if enabled
  python_virtualenv "#{application}-create-virtualenv" do
    path virtualenv
    interpreter lazy { python_interpreter_path_from(version_from(python_version_file)) }
    options virtualenv_options
    owner application_user unless application_path_is_nfs_mount
    group application_group unless application_path_is_nfs_mount
    only_if { virtualenv_enabled }
  end

  # Install pybundler into venv if enabled
  python_pip 'pybundler' do
    options "--index-url #{node['sendgrid_application_python']['pybundler']['index_url']}"
    user application_user unless application_path_is_nfs_mount
    group application_group unless application_path_is_nfs_mount
    virtualenv virtualenv
    only_if { virtualenv_enabled }
  end

  # Determine how to install dependencies
  dependency_file = case
  when ::File.exist?(pip_install_lock)
    pip_install_lock
  when ::File.exist?(requirements_txt)
    requirements_txt
  else
    nil
  end

  if dependency_file
    # Install dependencies via pip
    sendgrid_application_python_pip dependency_file do
      virtualenv virtualenv
      user application_user
      group application_group
      timeout timeout
    end
  else
    # If the dependencies were not installed via pip,
    # install the application with setuptools
    sendgrid_application_python_setuptools setup_py do
      virtualenv virtualenv
      user application_user
      group application_group
      timeout timeout
      only_if { ::File.exist?(setup_py) }
    end
  end
end
