include Chef::SendgridOhai::Helpers
include Chef::SendgridApplication::Helpers
include Chef::SendgridApplicationPython::Helpers

# Trigger notification on any notification from underlying resources
use_inline_resources

action :create do
  name = new_resource.name
  application_name = new_resource.application_name || name
  application_mode = new_resource.application_mode || new_resource.mode || :deployment
  application_path = sendgrid_application_path(application_name, application_mode, 'current')
  application_user = new_resource.user || sendgrid_application_user(application_mode)
  application_group = new_resource.group || sendgrid_application_group(application_mode)
  virtualenv = virtualenv_path(application_name, application_mode) if new_resource.virtualenv_enabled

  # Errno::EPERM is thrown when attempting to chown files on remote filesystems
  application_path_is_nfs_mount = path_is_nfs_mount(application_path)

  case application_mode
  when :deployment
    config_path = "#{application_path}/config/gunicorn.#{name}.py"

    directory "#{application_path}/config" do
      owner application_user
      group application_group
      mode 00744
      action :create
    end
  else
    config_path = "/var/tmp/gunicorn.#{name}.py"
  end

  %w(
    gunicorn
    gevent
  ).each do |pip|
    python_pip pip do
      user application_user unless application_path_is_nfs_mount
      group application_group unless application_path_is_nfs_mount
      virtualenv virtualenv
    end
  end

  # Setup a unicorn template
  ip = ip_from_interface(new_resource.interface)
  template config_path do
    source 'gunicorn.py.erb'
    cookbook 'sendgrid_application_python'
    variables({
      :worker_processes => new_resource.workers,
      :worker_connections => new_resource.worker_connections,
      :timeout => new_resource.timeout,
      :keepalive => new_resource.keepalive,
      :working_directory => application_path,
      :listen => "#{ip}:#{new_resource.port}",
      :preload => new_resource.preload.to_s.capitalize,
      :backlog => new_resource.backlog,
      :user => application_user,
    })
    owner application_user unless application_path_is_nfs_mount
    group application_group unless application_path_is_nfs_mount
    mode 00644
  end

  sendgrid_application_upstart_job name do
    application_name application_name
    application_mode application_mode
    environment new_resource.environment
    start_command "#{application_path}/venv/bin/gunicorn -c #{config_path} #{new_resource.app_module}"
    user application_user
  end
end
