include Chef::SendgridApplication::Helpers
include Chef::SendgridApplicationPython::Helpers

use_inline_resources # Trigger notification on any notification from underlying resources

action :create do
  application = new_resource.name
  application_mode = :development
  daemon_user = new_resource.daemon_user
  daemon_start_command = new_resource.daemon_start_command
  virtualenv_enabled = new_resource.virtualenv_enabled
  virtualenv_options = new_resource.virtualenv_options

  # Clone application
  sendgrid_application_development_from_scm application do
    repository new_resource.repository
    revision new_resource.revision
  end

  # Install dependencies
  sendgrid_application_python_dependencies application do
    mode application_mode
    virtualenv_enabled virtualenv_enabled
    virtualenv_options virtualenv_options
  end

  # Create upstart job
  if daemon_start_command
    sendgrid_application_python_upstart_job application do
      start_command daemon_start_command
      user daemon_user
      application_mode application_mode
      virtualenv_enabled virtualenv_enabled
      only_if { daemon_start_command }
    end
  end

end
