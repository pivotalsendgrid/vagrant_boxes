#
# Cookbook Name:: sendgrid_application_python
# Recipe:: deployment
#
# Copyright (C) 2013 SendGrid
#
# All rights reserved - Do Not Redistribute
#
%w{
  sendgrid_application::deployment
  sendgrid_application_python::_common
}.each do |obj|
  include_recipe obj
end
