#
# Cookbook Name:: sendgrid_application_python
# Recipe:: test
#
# Copyright (C) 2013 SendGrid
#
# All rights reserved - Do Not Redistribute
#
Chef::Recipe.send(:include, Chef::SendgridApplication::Helpers)
Chef::Recipe.send(:include, Chef::SendgridApplicationPython::Helpers)

%w{
  sendgrid_application_python::development
  sendgrid_application_python::deployment
}.each do |obj|
  include_recipe obj
end

user = sendgrid_application_user(:development)
group = sendgrid_application_group(:development)

# Global install sgsendlib into python 2.6 site-packages
sendgrid_application_package 'sgsendlib = 1.1.1'

# Install desired python version based upon project
python_version_file = "/tmp/#{PYTHON_VERSION_BASENAME}"
cookbook_file python_version_file
sendgrid_application_package "install python from #{python_version_file}" do
  package_name lazy { python_package_name_from(version_from(python_version_file)) }
end

# Create python 2.7.6 virtualenv for development
virtualenv = "/tmp/#{VIRTUALENV_BASENAME}"
python_virtualenv virtualenv do
  interpreter lazy { python_interpreter_path_from(version_from(python_version_file)) }
  owner user
  group group
end

# Install requirements using virualenv pip
requirements_txt = "/tmp/#{REQUIREMENTS_TXT_BASENAME}"
cookbook_file requirements_txt
sendgrid_application_python_pip requirements_txt do
  virtualenv virtualenv
  user user
  group group
end

application = 'boomerang'
repository = 'git@github.com:sendgrid/toolbox.git'
revision = 'master'
virtualenv_options = '--system-site-packages'

# Test development_from_scm
sendgrid_application_python_development_from_scm application do
  repository repository
  revision revision
  virtualenv_options virtualenv_options
end

# Test package_from_scm
sendgrid_application_python_package_from_scm application do
  repository repository
  revision revision
  virtualenv_options virtualenv_options
  #notifies :restart, "sendgrid_upstart_service[#{name}]"
end

# Serve requests via gunicorn
sendgrid_application_python_gunicorn_job application do
  port 3232
  app_module 'sg.event_sink.http:app'
end

sendgrid_upstart_service application do
  action :start
end
