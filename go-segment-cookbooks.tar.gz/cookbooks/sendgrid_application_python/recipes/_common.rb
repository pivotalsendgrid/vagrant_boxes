#
# Cookbook Name:: sendgrid_application_python
# Recipe:: _common
#
# Copyright (C) 2013 SendGrid
#
# All rights reserved - Do Not Redistribute
#

node.default['python']['setuptools_version'] = node['sendgrid_application_python']['setuptools_version']
include_recipe 'python'

python_pip 'pybundler' do
  options "--index-url #{node['sendgrid_application_python']['pybundler']['index_url']}"
end
