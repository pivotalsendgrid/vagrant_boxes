default['sendgrid_application_python']['pybundler']['index_url'] = 'http://pypi.repo.sjc1.sendgrid.net/simple/'
default['sendgrid_application_python']['setuptools_version'] = '1.1.6'
default['sendgrid_application_python']['development']['default_python_version'] = '2.6.6'
default['sendgrid_application_python']['deployment']['default_python_version'] = '2.6.6'
