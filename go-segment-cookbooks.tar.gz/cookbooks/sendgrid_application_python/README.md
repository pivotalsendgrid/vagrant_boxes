# sendgrid_application_python cookbook

## Recipes

The descriptions below assume you have an understanding of Chef and how
SendGrid usage of Chef generally works. If not see
[ApplicationCookbooks](https://wiki.sendgrid.net/display/CHEF/Cookbook+Development)
for more information before continuing.


### <a name="recipe-deployment"></a>deployment
This recipe is responsible for setting up the python deployment environment
needs. This should be included in downstream `deployment`
recipes for components. NOTE This does not include ops (i.e.
staging/production) specific items such as rsyslog, logrotate, sensu, etc.
This should be the minimal needs to deploy an component for integration with
other components.


### <a name="recipe-deployment_ops"></a>deployment\_ops
This recipe inherits the [`deployment`](#recipe-deployment) recipe and adds on
ops type items such as rsyslog, logrotate, sensu, etc. This should be included
in downstream `deployment_ops` recipes for components.


### <a name="recipe-development"></a>development
This recipe is responsible for setting up the python development environment
needs, such as setuptools, pip and virutalenv. This should be included in downstream
`development` recipes for components.



## Resources

### <a name="resource-sendgrid_application_python_dependencies"></a>sendgrid\_application\_python\_dependencies

Install OS dependencies and python dependencies.  OS dependencies are parsed
from the `.project.yml` and python dependencies are parsed first from `Pipfile.install.lock`, then from `requirements.txt` with pip. If deps were installed from the `Pipfile.install.lock`, `requirements.txt` will be ignored. If neither are available, then setuptools will execute `setup.py`.

#### Attributes
* __name:__ The identifier of python application.  Required. (name\_attribute).
* __mode:__ Mode of operation (:development or :deployment)
* __virtualenv_enabled:__ Boolean to enable/disable virtualenv.  Optional. Default is true
* __virtualenv_options:__ Options used when creating virtualenv. Optional. Ignored if nil.
* __timeout:__ Option to set timeout for execution.  Optional.  Falls back to default of execute/shell_out if not set.

#### Actions
* __install:__ Install dependencies for python application.  Default.


### <a name="resource-sendgrid_application_python_development_from_scm"></a>sendgrid\_application\_python\_development\_from\_scm
**requires [`development`](#recipe-development) recipe**

Clone application repo and install application dependencies using
[`sendgrid_application_python_dependencies`](#resources-sendgrid_application_python_dependencies) LWRP.

#### Attributes
* __name:__ The identifier of python application.  Required. (name\_attribute).
* __repository:__ The repository to clone from. Optional.
Defaults to `git@github.com:sendgrid/{name}.git`.
* __revision:__ The revision to clone from. Optional. Defaults to `HEAD`.
* __virtualenv_enabled:__ Boolean to enable/disable virtualenv.  Optional. Default is true
* __virtualenv_options:__ Options used when creating virtualenv. Optional. Default is nil
(suggested `--system-site-packages`)

#### Actions
* __create:__ Create sendgrid application development python from scm.  Default.


### <a name="sendgrid_application_python_package_from_scm"></a>sendgrid\_application\_python\_package\_from\_scm
**requires [`deployment`](#recipe-deployment) recipe**

Emulates `package` resource, but obtains code from SCM and optionally
create an upstart job.  __NOTE:__ callee still has to declare
a `sendgrid_upstart_service` resource to enable/start upstart service.
Services are not enabled or started automatically.

Supports all applicable conventions of `package` resource, such as
`DEPLOY=1` functionality. This resource uses the deploy\_revision format
by default with a current, shared and releases directory structure.

#### Attributes
* __name:__ The identifier for this package. Required. (name\_attribute).
* __repository:__ The repository to clone from. Optional.  Defaults to
`git@github.com:sendgrid/{name}.git`.
* __revision:__ The revision to clone from.  Optional.  Defaults to `HEAD`.
* __daemon\_start\_command:__ The command to execute the upstart daemon.  Optional.
* __daemon\_user:__ The user to run the daemon as.  Optional.
Default to `node['sendgrid_application']['deployment']['user']`.
* __virtualenv_enabled:__ Boolean to enable/disable virtualenv.  Optional. Default is true
* __virtualenv_options:__ Options used when creating virtualenv. Optional. Default is nil
(suggested `--system-site-packages`)

#### Actions
* __install:__ Install sendgrid application python package from scm.  Default.


### <a name="resource-sendgrid_application_python_pip"></a>sendgrid\_application\_python\_pip

Thin wrapper for pip python package manager.  This LWRP only supports
installing and uninstalling pips from a requirements.txt file (created via pip freeze)

** Note: ** When `virtualenv` is set to false, packages will always be installed by the root user.

#### Attributes
* __requirements_txt:__ The path to the requirements.txt pip file.
Required.  (name\_attribute)
* __options:__ Options to pass to the pip command.  Optional.
* __virtualenv:__ The path of the virtualenv. Optional. Ignored if nil.
* __user:__ The user to run the pip command as. Required
* __group:__ The group to run the pip command as. Required
* __timeout:__ Option to set timeout for execution.  Optional.  Falls back to default of shell_out if not set.

#### Actions
* __install:__ Install pips in requirements.txt.  Default.
* __uninstall:__ Uninstall pips listed in requirements.txt.


### <a name="resource-sendgrid_application_python_setuptools"></a>sendgrid\_application\_python\_setuptools

Thin wrapper for setuptools python build tool.  This LWRP only supports
install, build and develop command of setuptools.

#### Attributes
* __setup_py:__ The path to the setup.py setuptools file.
Required. (name\_attribute)
* __options:__  Options to pass to the pip command. Optional
* __virtualenv:__ The path of the virtualenv. Optional. Ignored if nil.
* __user:__ The user to run the setuptools command as. Root is used if virtualenv is nil.
* __group:__ The group to run the setuptools command as. Root is used if virtualenv is nil.
* __timeout:__ Option to set timeout for execution.  Optional.  Falls back to default of execute.

#### Actions
* __install:__ Run setuptools install command (default)
* __build:__ Run setuptools build command
* __develop:__ Run setuptools develop command

### sendgrid_application_upstart_job

Writes an Upstart job for a SendGrid application.

* __name:__ (name_attribute) The name of the job.
* __application_name:__ The application this job belongs to; defaults to `name`.
* __user:__ The user to run this job as; defaults to the standard deployment user.
* __application_mode:__ (optional) The application mode of the upstart job; defaults to `:deployment`
* __virtualenv_enabled:__ Boolean to enable/disable virtualenv.  Optional. Default is true.* __virtualenv_enabled:__ Boolean to enable/disable virtualenv.  Optional. Default is true
* __environment:__ Environment variables to set for the job.
* __start_command:__ (required) The command to start the application.
* __start_on:__ (optional) The runlevels to start this service in; defaults to sendgrid_upstart_job defaults.
* __stop_on:__ (optional) The runlevels to stop this service in; defaults to sendgrid_upstart_job defaults.

### sendgrid\_application\_python\_gunicorn\_job

Writes an [gunicorn](http://gunicorn.org/) job for a SendGrid python application.

* __name:__ (name_attribute) The name of the job.
* __application\_name:__ The application this job belongs to; defaults to
`name`.
* __application\_mode:__ Mode of operation (:development or :deployment) **default: :development**
* __environment:__ Hash of environment variables to pass to the Upstart job
* __app_module:__ Refers to a WSGI callable that should be found in the specified module e.g., MODULE\_NAME:VARIABLE\_NAME. **Required**
* __user:__ The user to run this job as. **default: standard deployment user**
* __group:__ The group to run this job as. **default: standard deployment user**
* __interface:__ The IP address for gunicorn to listen on. **default: '127.0.0.1'**
* __port:__ The port for Unicorn to listen on (default: 3000).
* __workers:__ The number of workers for Unicorn to start. **default: 1**
* __worker\_connections__: The maximum number of simultaneous clients per worker process. **default: 1000**
* __timeout__: Workers silent for more than this many seconds are killed and restarted. **default: 30**
* __keepalive__: The number of seconds to wait for requests on a Keep-Alive connection. **default: 2**
