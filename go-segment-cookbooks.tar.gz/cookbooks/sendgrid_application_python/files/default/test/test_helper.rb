#
# Cookbook:: sendgrid_application_python
#

module Helpers
  module PythonPackages
    require 'chef/mixin/shell_out'
    include Chef::Mixin::ShellOut

    def assert_python_version(expected_version, python_exe='python')
      process = shell_out! "#{python_exe} --version"
      process.exitstatus.must_equal(0)
      actual = process.stderr
      expected = "Python #{expected_version}"
      assert actual.include?(expected), "Expected '#{expected}' (actual: '#{actual}') (python_exe: #{python_exe})"
    end

    def assert_python_package(expected_name, expected_version=nil, pip_exe='pip')
      process = shell_out "#{pip_exe} show #{expected_name}"
      process.exitstatus.must_equal(0)
      actual = process.stdout
      expected_name = expected_name.prepend("Name: ")
      assert actual.include?(expected_name), "Expected package '#{expected_name}' to be installed (actual: '#{actual}') (pip_exe: #{pip_exe})"
      if expected_version
        expected_version = expected_version.prepend("Version: ")
        assert actual.include?(expected_version), "Expected package '#{expected_name}' to be version '#{expected_version}' (actual: '#{actual}') (pip_exe: #{pip_exe})"
      end
    end
  end
end
