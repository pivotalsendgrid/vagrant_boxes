require 'minitest/spec'
require File.expand_path('../test_helper', __FILE__)

describe_recipe 'sendgrid_application_python::_common' do
  include Helpers::PythonPackages

  describe "python" do
    it "w/o pyenv, should have correct python version on the path for development" do
      assert_python_version(node['sendgrid_application_python']['default_python_version'])
    end

    it "should have setuptools" do
      assert_python_package 'setuptools', node['sendgrid_application_python']['setuptools_version']
    end

    it "should have a pip binary in the path" do
      assert_sh 'pip --version'
    end
  end

  describe "python packages" do
    it "should list python packages" do
      assert_sh 'pip list'
    end

    it "should have pybundle installed on the path" do
      assert_sh 'which pybundle'
    end
  end
end
