require 'minitest/spec'
require File.expand_path('../test_helper', __FILE__)

describe_recipe 'sendgrid_application_python::test' do

  include Helpers::PythonPackages
  include Chef::SendgridApplication::Helpers
  include Chef::SendgridApplicationPython::Helpers

  let(:deployment_path) { sendgrid_application_path('boomerang', :deployment, 'current') }
  let(:development_path) { sendgrid_application_path('boomerang', :development) }
  let(:python_version_basename) { Chef::SendgridApplicationPython::Helpers::PYTHON_VERSION_BASENAME }
  let(:virtualenv_basename) { Chef::SendgridApplicationPython::Helpers::VIRTUALENV_BASENAME }

  it ' development and deployment virtualenv pip/python exist and python matched .python-version' do
    [deployment_path, development_path].each do |application|
      python_version_file = "#{application}/#{python_version_basename}"
      venv_bin = "#{application}/#{virtualenv_basename}/bin"
      python_version = version_from(python_version_file)
      python_exe = "#{venv_bin}/python"
      pip_exe = "#{venv_bin}/pip"
      assert_python_version(python_version, python_exe)
      assert_python_package('sgsendlib', '1.1.1', "#{venv_bin}/pip")
    end
  end

  it ' pip install requirements.txt dependencies' do
    venv_bin = "/tmp/#{virtualenv_basename}/bin"
    assert_python_version('2.7.6', "#{venv_bin}/python")
    assert_python_package('ipython', '1.2.0', "#{venv_bin}/pip")
  end

  describe 'gunicorn_job' do
    it "started a gunicorn job on port 3232" do
      assert_sh("curl -s http://localhost:3232/ | grep 'DOCTYPE'")
    end
  end

end
