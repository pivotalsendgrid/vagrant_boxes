# TODO Perhaps we should support all package options?
actions :install
default_action :install

attribute :name, :kind_of => String, :name_attribute => true
attribute :repository, :kind_of => String
attribute :revision, :kind_of => String, :default => 'production'
attribute :daemon_start_command, :kind_of => String
attribute :daemon_user, :kind_of => String
attribute :virtualenv_enabled, :kind_of => [TrueClass, FalseClass], :default => true
attribute :virtualenv_options, :kind_of => String
