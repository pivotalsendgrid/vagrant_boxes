actions :install, :build, :develop
default_action :install

attribute :setup_py, :kind_of => String, :name_attribute => true
attribute :options, :kind_of => String
attribute :virtualenv, :kind_of => String
attribute :user, :kind_of => String
attribute :group, :kind_of => String
attribute :timeout, :kind_of => Integer
