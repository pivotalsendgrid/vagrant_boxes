actions :install
default_action :install

attribute :application, :kind_of => String, :name_attribute => true
attribute :virtualenv_enabled, :kind_of => [TrueClass, FalseClass], :default => true
attribute :virtualenv_options, :kind_of => String
attribute :mode, :kind_of => Symbol, :required => true
attribute :timeout, :kind_of => Integer
