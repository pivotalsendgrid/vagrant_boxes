actions :install
default_action :install

attribute :requirements_txt, :kind_of => String, :name_attribute => true
attribute :options, :kind_of => String
attribute :virtualenv, :kind_of => String
attribute :user, :kind_of => String, :required => true
attribute :group, :kind_of => String, :required => true
attribute :timeout, :kind_of => Integer
