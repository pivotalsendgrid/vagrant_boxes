actions :create
default_action :create

attribute :name, :kind_of => String, :name_attribute => true
attribute :application_name, :kind_of => String
attribute :application_mode, :kind_of => Symbol, :equal_to => [:development, :deployment], :default => :deployment
attribute :environment, :kind_of => Hash
attribute :log_format, :kind_of => String
attribute :user, :kind_of => String
attribute :virtualenv_enabled, :kind_of => [TrueClass, FalseClass], :default => true

attribute :start_command, :kind_of => String, :required => true
attribute :start_on, :kind_of => String
attribute :stop_on, :kind_of => String
