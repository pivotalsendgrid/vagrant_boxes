actions :create
default_action :create

attribute :name, :kind_of => String, :name_attribute => true
attribute :application_name, :kind_of => String
attribute :application_mode, :equal_to => [:development, :deployment]
attribute :mode, :equal_to => [:development, :deployment] # FIXME: deprecated
attribute :virtualenv_enabled, :kind_of => [TrueClass, FalseClass], :default => true
attribute :environment, :kind_of => Hash
attribute :app_module, :kind_of => String, :required => true
attribute :user, :kind_of => String
attribute :group, :kind_of => String
attribute :interface, :kind_of => String, :default => '127.0.0.1'
attribute :port, :kind_of => Integer, :default => 3000
attribute :workers, :kind_of => Integer, :default => 1
attribute :worker_connections, :kind_of => Integer, :default => 1000
attribute :preload, :kind_of => [TrueClass, FalseClass], :default => true
attribute :backlog, :kind_of => Integer, :default => 2048
attribute :timeout, :kind_of => Integer, :default => 30
attribute :keepalive, :kind_of => Integer, :default => 2
