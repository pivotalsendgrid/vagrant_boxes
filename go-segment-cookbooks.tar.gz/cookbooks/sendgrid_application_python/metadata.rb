name             'sendgrid_application_python'
maintainer       'SendGrid'
maintainer_email 'operations@sendgrid.com'
license          'All rights reserved'
description      'Installs/Configures sendgrid_application_python'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '2.10.3'

depends          'sendgrid_application', '~> 7.18'
depends          'sendgrid_upstart', '~> 1.0'
depends          'sendgrid_ohai', '~> 0.2'
depends          'python', '~> 1.4'
