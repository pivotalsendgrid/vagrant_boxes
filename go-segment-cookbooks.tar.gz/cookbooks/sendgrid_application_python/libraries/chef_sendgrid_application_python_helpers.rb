#
# Cookbook Name:: sendgrid_application
# Library:: Chef::SendgridApplication::Helpers
#
# Private Code, All rights reserved
#

class Chef
  module SendgridApplicationPython
    module Helpers

      # Constants for python applications
      VIRTUALENV_BASENAME = 'venv'
      REQUIREMENTS_TXT_BASENAME = 'requirements.txt'
      PIP_INSTALL_LOCK_BASENAME = 'Pipfile.install.lock'
      SETUP_PY_BASENAME = 'setup.py'
      PYTHON_VERSION_BASENAME = '.python-version'

      ##
      # Return the virtualenv path for a sendgrid_application_python
      # based upon mode.
      def virtualenv_path(application, mode)
        "#{sendgrid_application_path(application, mode, 'current')}/#{VIRTUALENV_BASENAME}"
      end

      ##
      # Warp a command with a virtualenv activation script if enabled
      # @return [String] wrapped command
      def virtualenv_activation_wrapper(virtualenv, command)
        command.prepend("source #{virtualenv}/bin/activate && ") if virtualenv && command
        command
      end

      ##
      # Return python package name for supplied version.
      # NOTE: default python package is not namespaced with a version.
      # Example for centos6:
      # 2.6 (deault) => 'python' rpm package namespace
      # 2.7 (non-default) => 'python2.7' rpm package namespace
      # @return [String] python_package_name or nil
      # @todo refactor to using pyenv so python version are not hardcoded
      def python_package_name_from(python_version)
        case python_version
        when '2.6', '2.6.6'
          'python'
        when '2.7', '2.7.6'
          'python2.7'
        else
          nil
        end
      end

      ##
      # Return python interpreter path for supplied version.
      # If a package is not available for supplied version nil is returned.
      # NOTE: default python executable is not namespaced with a version.
      # Example for centos6:
      # 2.6 (deault) => '/usr/bin/python'
      # 2.7 (non-default) => '/usr/local/bin/python2.7'
      # @return [String] python_interpreter or nil
      # @todo refactor to using pyenv so python version are not hardcoded
      def python_interpreter_path_from(python_version)
        case python_version
        when '2.6', '2.6.6'
          "/usr/bin/#{python_package_name_from(python_version)}"
        when '2.7', '2.7.6'
          "/usr/local/bin/#{python_package_name_from(python_version)}"
        else
          nil
        end
      end

      def pip_versions_from(requirements_txt)
        Hash[*File.read(requirements_txt).split(/==|\n/)]
      end

    end
  end
end
