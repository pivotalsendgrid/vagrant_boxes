# CHANGELOG for sendgrid_application_python
This file is used to list changes made in each version of sendgrid_application_python.

## 2.10.3
- Fixed bug where we shell_out to call pip and pip uses root

## 2.10.2
- Fixed a bug where pip was installing packages into the virtualenv with
incorrect permissions

## 2.10.1
- Fixed bug where pybundler was not available if virutalenv enabled.

## 2.10.0
- Added pybundler python package to be installed by _common recipe.  Added
  tests to ensure pybundle is available on command line.

## 2.9.0
- Added support for passing in a timeout to sendgrid_application_python_dependencies, sendgrid_application_python_pip and sendgrid_application_python_setuptools because some libraries require enough compile time that they surpass the default 600 seconds.

## 2.8.1
- Fixed bug when prefixing PIP_CONFIG_FILE

## 2.8.0
- Prefix PIP_CONFIG_PATH value to pip install commands when value exists.

## 2.7.0
- Add `environment` and `application_mode` options to `gunicorn_job`
- Write gunicorn config to /var/tmp in development
- Fix NFS bug in gunicorn_job

## 2.6.0
- Changed pip lwrp to use shell_out call to pip install -r <requirements_txt> file
  rather than parsing file and calling python_pip lwrp.  Parsing logic was limited
  to only == dependencies in requirements.txt which caused issue in some components.

## 2.5.0
- Install a specific version of setuptools using python cookbook and attributes
  rather than explicit call to python_pip LWRP.  Includes new test for setuptools
  version.  Default version for setuptools stays at 1.1.6.

## 2.4.0
- Adds the ability to install deps from pip via Pipfile.install.lock
  Note: When both a requirements.txt and a Pipfile.install.lock exist,
        the lock file will take precedence over requirments.txt.
- Modifies dependency installation to _only_ install from either pip or setuptools.
- Fixes a permissions bug when installing packages from a non-virtual environment.
  System packages will now be installed by the root user.

## 2.3.0
- added ability to have python upstart job with different name than application.

## 2.2.2
- Adds `sendgrid_application_gunicorn_job` LWRP

## 2.2.1
- Fixed virtualenv path creation in upstart_job LWRP.

## 2.2.0
- In development_from_scm change from mode to application_mode attribute name

## 2.1.0
- Added optional upstart command and user to development_from_scm LWRP.

## 2.0.1
- Added pip install of setuptools 1.1.6 so all python apps use
  same version of setuptools (ez_install was giving problems)

## 2.0.0
- Moved deployment venv from shared to current folder so virtualenvs
  can be tied to a specific release.

## 1.3.0
- Added call to setuptools install from dependencies LWRP
- Fixed application path when processing dependencies in deployment mode
- Virtualenv functions properly deal with nil virtualenv path
- Fixed tests to use hard coded version of sgsendlib rpm
- Default setuptools user/group to root, no longer required

## 1.2.0
- Updates for yum cookbook v3.x

## 1.1.1
- Bugfix INF-323: sg_app_py package_from_scm fails w/o daemon startup command

## 1.1.0
- Added sendgrid_application_go_dependencies to install both OS and
python dependencies.  This allows for reuse in application ci_dependencies
cookbooks where code is already available via vagrant mount.
- Daemon start command was unnecessarily forced to required.  Now is optional.
- Removed .python-version usage.  Forces virtualenv to use system python version.

## 1.0.3
- Replace `user` and `group` options in `package_from_scm` LWRP with
`daemon_user` option and make `pip` and `setuptools` behave properly when
virtualenv is disabled.

## 1.0.2
- Include `sendgrid_application::deployment_ops` from `deployment_ops`

## 1.0.1
- Replace `daemon_user` option in `package_from_scm` with `user` and `group`
options, which are passed down to child LWRPs so that everything happens as
the same user/group.

## 1.0.0
- Updates to development and deployment recipes
- Merged build recipe into development recipe
- Add package_from_scm LWRP
- Rename development -> development_from_scm LWRP
- Remove deployment_from_scm LWRP
- Move recipe default to _common
- Add deployment_ops recipe

## 0.10.1
- Remove remaining PIP installs, require projects to specify their own
requirements.

## 0.10.0
- Add :restart action to default LWRP to signal down into underlying service
- Add package_from_scm LWRP to be used in ::default recipes for install
components before they are properly packaged.

## 0.9.1
- Fix default LWRP to pip uninstall the app so that it doesn't conflict with
running from SCM directory.

## 0.9.0

- Update `sendgrid_application` dependency
- Add `templates` option to `default` LWRP

## 0.8.8

- Update dependencies

## 0.8.7

- Install virtualenv into shared directory
- Fix bug where services were being created unnecessarily

## 0.8.6

- Fix notifications from `default` LWRP

## 0.8.5

- Add `virtualenv_enabled` option to `default` LWRP
- Automatically install depependencies from requirements.txt or setup.py

## 0.8.4

- Expose monit configs

## 0.8.3

- Add `virtualenv_options` option to `default` LWRP

## 0.8.2

- Add `interpreter` option to `default` LWRP

## 0.8.1

- Add `execute` option to `default` LWRP
- Ensure files are owned by the correct group
- Update test application

## 0.8.0

- Remove dependency on `application_python` and rewrite `default` LWRP so that
it actually works

## 0.7.0
- Bump requirement on sendgrid_application for package repo updates.
- Fixup tailor and foodcritic errors.

## 0.6.2
- Fix installation of distribute and setuptools to be clean and have latest
versions.

## 0.6.1
- Pickup upstream sendgrid_application bug fix

## 0.6.0:

- Add fixes for infrastructure team

## 0.5.2:

* Ensure that the correct default python modules get installed in the correct
environments

## 0.5.1:

* Always install python (i.e. for both development and deployment)

## 0.5.0:

* Use `sendgrid_application` 6.0

## 0.4.0:

* Install OS packages for development

## 0.3.0:

* Updates for `sendgrid_application` 5.0

## 0.2.0:

* Update dependencies

## 0.1.0:

* Initial release of sendgrid_application_python

- - -
Check the [Markdown Syntax Guide](http://daringfireball.net/projects/markdown/syntax) for help with Markdown.

The [Github Flavored Markdown page](http://github.github.com/github-flavored-markdown/) describes the differences between markdown on github and standard markdown.
