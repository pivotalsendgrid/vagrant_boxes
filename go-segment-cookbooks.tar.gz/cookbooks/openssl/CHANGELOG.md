openssl Cookbook CHANGELOG
==========================
This file is used to list changes made in each version of the openssl cookbook.


v2.0.0 (2014-06-11)
-------------------
#1 - [COOK-847] - Add LWRP for generating self signed certs
#4 - [COOK-4715] - add upgrade recipe and complete test harness


v1.1.0
------
### Improvement
- **[COOK-3222](https://tickets.opscode.com/browse/COOK-3222)** - Allow setting length for `secure_password`

v1.0.2
------
- Add name attribute to metadata
