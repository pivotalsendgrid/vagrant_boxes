# CHANGELOG

## 1.1.1
- Don't error out when trying to restart a job that isn't started

## 1.1.0
- Add `start_on` and `stop_on` attributes for `sendgrid_upstart_jobs`

## 1.0.1
- put pid symlinks back we assumed that monit was updated on (allthe things) sym links are cheap

## 1.0.0
- Remove old pid symlinks

## 0.3.1
- Change location of pid from `/var/run/<name>/<name>.pid` to
`/var/run/<name>/pid`

## 0.3.0
- When running as root, use a bash login shell to load a sane environment
- Move pid files to `/var/run/<name>/<name>.pid` (symlink to old location)
- LWRP updates for Chef 11
- Add `sendgrid_upstart_service` HWRP

## 0.2.5
- Fix a bug where non-privileged users were not getting their environments
configured correctly.

## 0.2.4
- Run su with a login shell

## 0.2.3
- Add `respawn` option to `job` LWRP

## 0.2.2
- Run services as root by default
- Only wrap the start command in su if it needs to run as a non-privileged
user.
- Add `expect` option to `job` LWRP

## 0.2.1
- `job` LWRP should only write the job files without actually managing the
services.

## 0.2.0
- Add `job` LWRP

## 0.1.0
- Initial release
