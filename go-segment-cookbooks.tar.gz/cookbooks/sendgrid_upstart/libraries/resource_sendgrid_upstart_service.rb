require 'chef/resource'
require 'chef/resource/service'
require 'chef/provider/service/upstart'

class Chef
  class Resource
    class SendgridUpstartService < Chef::Resource::Service

      def initialize(name, run_context=nil)
        super

        @resource_name = :sendgrid_upstart_service

        # Set the default provider to Upstart. This should prevent Chef from
        # getting confused by our SysV init script wrapper.
        @provider = Chef::Provider::Service::Upstart

        # Change the default restart command to force a reload of the job
        # configuration file. Note that we check to see if the service is
        # running before trying to stop it. This prevents the "stop: Unknown
        # instance:" error.
        # See: http://upstart.ubuntu.com/cookbook/#initctl-restart
        @restart_command = "/sbin/status #{@name} 2>/dev/null | grep -q ' start/'; [[ $? -eq 0 ]] && /sbin/stop #{@name}; /sbin/start #{@name}"
      end

    end
  end
end
