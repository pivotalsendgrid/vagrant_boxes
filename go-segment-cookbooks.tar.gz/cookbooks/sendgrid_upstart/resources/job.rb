actions :create
default_action :create

attribute :name, :kind_of => String, :name_attribute => true
attribute :description, :kind_of => String
attribute :manual, :kind_of => [TrueClass, FalseClass], :default => false
attribute :respawn, :kind_of => [TrueClass, FalseClass], :default => false
attribute :environment, :kind_of => Hash, :default => {}
attribute :expect, :kind_of => String
attribute :user, :kind_of => String, :default => 'root'
attribute :start_command, :kind_of => String
attribute :start_on, :kind_of => String, :default => 'runlevel [2345]'
attribute :stop_on, :kind_of => String, :default => 'runlevel [06]'
