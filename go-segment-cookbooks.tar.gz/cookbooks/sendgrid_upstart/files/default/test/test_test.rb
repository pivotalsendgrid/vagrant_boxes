describe_recipe 'sendgrid_upstart::test' do

  it 'starts the test jobs' do
    %w{root vagrant}.each do |u|
      service("test_#{u}").must_be_running
      file("/var/run/test_#{u}/pid").must_exist
      pid = IO.read("/var/run/test_#{u}/pid")
      assert_sh("status test_#{u} | grep 'running, process #{pid}'")
      link("/var/run/test_#{u}.pid").must_exist.with(
        :link_type, :symbolic).and(:to, "/var/run/test_#{u}/pid")
    end
  end

end
