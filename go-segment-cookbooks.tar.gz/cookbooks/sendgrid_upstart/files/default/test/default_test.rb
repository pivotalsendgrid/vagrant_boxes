describe_recipe 'sendgrid_upstart' do

  it 'creates /lib/init/upstart-job' do
    file('/lib/init/upstart-job').must_exist.with(:mode, 00755)
  end

end
