# sendgrid_upstart cookbook

This cookbook manages [Upstart](http://upstart.ubuntu.com/).

# Usage

## Recipes

- **default**: Installs Upstart and a System V init script wrapper
- **test**: For testing only

## Resources

### sendgrid_upstart_job

This resource writes an Upstart job configuration file and creates a System V
init script (i.e. `/etc/init.d/<name>`) for convenience. Note that pid files
will be written to `/var/run/<name>/pid` for other applications that need them
(e.g. Monit).

- **name**: Name of the job (name_attribute)
- **description**: Optional description of the job (default: nil)
- **manual**: Indicates that this job should only be started manually (default:
false)
- **respawn**: Indicates that the service should automatically be respawned if
it dies. Usually [Monit](http://mmonit.com/monit/) would handle this for us
(via the [sendgrid_monit](https://github.com/sendgrid-ops/chef-sendgrid_monit)
cookbook), but this option is available for services you don't really care to
be alerted on. (default: false)
- **environment**: Hash of environment variable names to values (default: {})
- **expect**: Sets the [expect](http://upstart.ubuntu.com/cookbook/#expect)
stanza (default: nil)
- **user**: User to run the job as (default: root)
- **start_command**: Command to start the daemon (default: nil)

#### Example

    sendgrid_upstart_job 'example' do
      start_command 'ping 127.0.0.1'
    end

### sendgrid_upstart_service

This resource extends [service](http://docs.opscode.com/resource_service.html)
with Upstart specific features:

- Explicitly sets the Chef provider to `Chef::Provider::Service::Upstart`
- The `:restart` action calls `:stop` followed by `:start` to work around the
fact that [initctl's restart action doesn't cause the job to re-read its
configuration file](http://upstart.ubuntu.com/cookbook/#initctl-restart).

Note that this resource should **always** be used instead of `service` when
using `sendgrid_upstart_job`.

#### Example

    sendgrid_upstart_service 'example' do
      action :start
    end
