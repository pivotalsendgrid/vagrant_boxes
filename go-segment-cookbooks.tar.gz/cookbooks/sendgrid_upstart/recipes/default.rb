#
# Cookbook Name:: sendgrid_upstart
# Recipe:: default
#
# Copyright (C) 2013 SendGrid
#
# All rights reserved - Do Not Redistribute
#
package 'upstart'

directory '/lib/init/' do
  mode 00755
end

# Note: This file was stolen from Ubuntu and slightly modified. It allows you
# to create symlinks in /etc/init.d for Upstart jobs. For example:
#
#  link "/etc/init.d/#{service_name}" do
#    to '/lib/init/upstart-job'
#  end
cookbook_file '/lib/init/upstart-job' do
  source 'upstart-job'
  mode 00755
  not_if { node['platform'] == 'ubuntu' }
end
