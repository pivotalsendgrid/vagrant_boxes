#
# Cookbook Name:: sendgrid_upstart
# Recipe:: default
#
# Copyright (C) 2013 SendGrid
#
# All rights reserved - Do Not Redistribute
#
include_recipe 'sendgrid_upstart'

%w{
  root
  vagrant
}.each do |u|
  sendgrid_upstart_job "test_#{u}" do
    user u
    environment({
      'HOST' => 'localhost'
    })
    start_command "ping $HOST | logger -t test_#{u}"
    notifies :restart, "sendgrid_upstart_service[test_#{u}]"
  end

  sendgrid_upstart_service "test_#{u}" do
    action :start
  end
end
