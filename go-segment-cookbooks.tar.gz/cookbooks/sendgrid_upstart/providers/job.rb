use_inline_resources

action :create do

  start_command = new_resource.start_command

  # If we're running as root, use a bash login shell to load the environment.
  if new_resource.user == 'root'
    start_command = "bash -l -c '#{start_command}'"

  # If we're running as a non-privileged user, wrap the start command in su.
  # This is only needed for older versions of Upstart which don't have support
  # for the setuid/setgid stanzas.
  else
    # The --session-command flag needs to be used on CentOS. Otherwise, the
    # child processes never get killed when Upstart tries to stop the service.
    # The result is that once the service is started, it can never be stopped
    # or restarted.
    su_command_flag = case node['platform']
    when 'centos'
      '--session-command'
    when 'ubuntu'
      '--command'
    end

    # Since su resets the environment, non-privileged users won't have access
    # to environment variables set with Upstart's env stanzas. The simplest
    # workaround is to export them all inline.
    unless new_resource.environment.empty?
      environment = new_resource.environment.sort.inject('export ') { |memo, (n, v)| memo + "#{n}='#{v}' " } + '&& '
    end

    start_command = "su -l #{su_command_flag} '#{environment}#{start_command}' #{new_resource.user}"
  end

  pid_dir = "/var/run/#{new_resource.name}"
  directory pid_dir do
    owner new_resource.user
    mode 00755
  end

  template "/etc/init/#{new_resource.name}.conf" do
    cookbook 'sendgrid_upstart'
    source 'job.conf.erb'
    variables({
      :name => new_resource.name,
      :description => new_resource.description || "Manages #{new_resource.name}",
      :manual => new_resource.manual,
      :respawn => new_resource.respawn,
      :environment => new_resource.user == 'root' ? new_resource.environment : [], # Only relevant for root (see above)
      :expect => new_resource.expect,
      :pid_file => "#{pid_dir}/pid", # Write a pid file for other applications that might need it (e.g. monit)
      :start_command => start_command,
      :start_on => new_resource.start_on,
      :stop_on => new_resource.stop_on
    })
    mode 00644
  end

  link "/etc/init.d/#{new_resource.name}" do
    to '/lib/init/upstart-job'
  end
end
