name             'sendgrid_upstart'
maintainer       'SendGrid'
maintainer_email 'operations@sendgrid.com'
license          'All rights reserved'
description      'Installs/Configures sendgrid_upstart'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '1.1.1'
