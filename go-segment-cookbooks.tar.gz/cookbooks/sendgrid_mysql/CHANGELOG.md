# CHANGELOG

## 2.2.0
- New minor version
- Remove the my.cnf template and move the creation of that file to an LWRP

## 2.1.8
- Adding shared-compat

## 2.1.7
- Explicitly install Percona shared with development packages

## 2.1.6
- Add a start to mysql only if it isn't already running
- Fix the silent fail of where the pid file gets created
- Move the option file include to the right group

## 2.1.5
- Use a conditional around my.cnf notifier handling

## 2.1.4
- Fix the includedir in mysql cnf

## 2.1.3
- Make the conf dir a server attrib
- Create the conf dir

## 2.1.2
- Attributize the production conf dir too

## 2.1.1
- Attributize logdir and datadir so we can override them in production cookbooks/envs
- Add and !include line in my.cnf
- Edit the README to not say 'development only'

## 2.1.0
- Stop using mysql and build-essential community cookbooks
- Fix bug where recipes were order dependent
- Remove obsolete Ubuntu code
- Remove obsolete ruby recipe
- Allow dots in `mysql_version` attribute

## 2.0.1
- Fix bug in `ruby` recipe

## 2.0.0
- use a more recent version of the community mysqlcookbook
- Add auto_correct to the port mapping

## 1.1.6
- Install MySQL 5.5 by default

## 1.1.5
- Install OpenSSL development headers in development_headers recipe

## 1.1.4
- Allow remote MySQL access for development environment

## 1.1.3
- Relax dependencies

## 1.1.2
- Fix broken configuration on Ubuntu

## 1.1.1
- Fixed collation-server setting

## 1.1.0
- Added template for /etc/my.cf defining server character set, collation and transaction isolation level

## 0.1.1
- Fix Chef::Exceptions::ResourceNotFound exception when including this cookbook
from others
- Small improvement to server test

## 0.1.0
- Initial release
