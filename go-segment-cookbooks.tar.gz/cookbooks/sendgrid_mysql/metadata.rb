name             'sendgrid_mysql'
maintainer       'SendGrid'
maintainer_email 'operations@sendgrid.com'
license          'All rights reserved'
description      'Installs/Configures sendgrid_mysql'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '2.2.0'
