# sendgrid_mysql cookbook

This cookbook installs MySQL (from Percona).

This book serves as a 'core' mysql cookbook to install a bare bones MySQL Percona instance
and is wrapped by our production Db deployment cookbooks

## Recipes

* **client**: Installs the MySQL client
* **default**: Alias for **client**
* **development_headers**: Installs MySQL client development headers
* **server**: Installs the MySQL server
