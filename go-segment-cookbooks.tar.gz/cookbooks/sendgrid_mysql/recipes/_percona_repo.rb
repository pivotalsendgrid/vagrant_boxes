#
# Cookbook Name:: sendgrid_mysql
# Recipe:: _percona_repo
#
# Copyright (C) 2013 SendGrid
#
# All rights reserved - Do Not Redistribute
#
remote_file "#{Chef::Config[:file_cache_path]}/percona-release-#{node['sendgrid_mysql']['percona_repo_version']}.#{node['kernel']['machine']}.rpm" do
  source "http://www.percona.com/downloads/percona-release/percona-release-#{node['sendgrid_mysql']['percona_repo_version']}.#{node['kernel']['machine']}.rpm"
end

rpm_package 'percona-release' do
  source "#{Chef::Config[:file_cache_path]}/percona-release-#{node['sendgrid_mysql']['percona_repo_version']}.#{node['kernel']['machine']}.rpm"
end
