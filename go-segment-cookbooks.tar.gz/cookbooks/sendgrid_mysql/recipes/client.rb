#
# Cookbook Name:: sendgrid_mysql
# Recipe:: client
#
# Copyright (C) 2013 SendGrid
#
# All rights reserved - Do Not Redistribute
#
include_recipe 'sendgrid_mysql::_percona_repo'

%W{
  Percona-Server-client-#{node['sendgrid_mysql']['mysql_version'].gsub('.', '')}
}.each do |obj|
  package obj
end
