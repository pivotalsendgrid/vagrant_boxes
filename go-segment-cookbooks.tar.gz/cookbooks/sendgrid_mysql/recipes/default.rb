#
# Cookbook Name:: sendgrid_mysql
# Recipe:: default
#
# Copyright (C) 2013 SendGrid
#
# All rights reserved - Do Not Redistribute
#
include_recipe 'sendgrid_mysql::client'
