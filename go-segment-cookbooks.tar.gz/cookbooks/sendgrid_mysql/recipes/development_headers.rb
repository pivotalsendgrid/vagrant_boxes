#
# Cookbook Name:: sendgrid_mysql
# Recipe:: development_headers
#
# Copyright (C) 2013 SendGrid
#
# All rights reserved - Do Not Redistribute
#
include_recipe 'sendgrid_mysql::client'

%W{
  Percona-Server-devel-#{node['sendgrid_mysql']['mysql_version'].gsub('.', '')}
  Percona-Server-shared-#{node['sendgrid_mysql']['mysql_version'].gsub('.', '')}
  Percona-Server-shared-compat
  openssl-devel
}.each do |obj|
  package(obj)
end
