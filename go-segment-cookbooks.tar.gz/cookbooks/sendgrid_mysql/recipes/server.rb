#
# Cookbook Name:: sendgrid_mysql
# Recipe:: server
#
# Copyright (C) 2013 SendGrid
#
# All rights reserved - Do Not Redistribute
#
include_recipe 'sendgrid_mysql::client'

%W{
  Percona-Server-server-#{node['sendgrid_mysql']['mysql_version'].gsub('.', '')}
}.each do |obj|
  package obj
end

service 'mysql' do
  action :nothing
end

sendgrid_mysql_conf "my.cnf" do
  path '/etc/my.cnf'
  options node['sendgrid_mysql']['server']['config']
  owner 'mysql'
  group 'mysql'
  if node['sendgrid_mysql']['restart']
    notifies :restart, 'service[mysql]', :immediately
  else
    Chef::Log.info "MySQL configuration was updated will only start MySQL if it isn't already running"
    notifies :start, 'service[mysql]', :immediately
    not_if { File::exists?(node['sendgrid_mysql']['server']['pid']) }
  end
end

file '/home/vagrant/.my.cnf' do
  content "[client]\nuser=root\n"
  mode 00644
  owner 'vagrant'
  group 'vagrant'
  only_if 'getent passwd vagrant'
end

# Allow remote access for development environment
execute 'echo "grant all on *.* to \'root\'@\'%\'; flush privileges" | mysql' do
  only_if { node.chef_environment == '_default' }
end
