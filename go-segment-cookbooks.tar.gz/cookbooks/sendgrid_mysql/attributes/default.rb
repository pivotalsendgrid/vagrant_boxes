default['sendgrid_mysql']['percona_repo_version'] = '0.0-1'
default['sendgrid_mysql']['mysql_version'] = '5.5'
default['sendgrid_mysql']['logdir'] = '/var/log'
default['sendgrid_mysql']['datadir'] = '/var/lib/mysql'
default['sendgrid_mysql']['server']['pid'] = "#{node['sendgrid_mysql']['datadir']}/mysqld.pid"
default['sendgrid_mysql']['restart'] = true
