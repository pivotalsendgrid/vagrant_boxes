default['sendgrid_mysql']['server']['config'] = {
  'mysqld' => {
    'socket' => "#{node['sendgrid_mysql']['datadir']}/mysql.sock",
    'datadir' => '/var/lib/mysql',
    'pid-file' => node['sendgrid_mysql']['server']['pid'],
    'user' => 'mysql',
    'character-set-server' => 'utf8',
    'collation-server' => 'utf8_general_ci',
    'symbolic-links' => '0'
  },
  'mysqld_safe' => {
    'log-error' => "#{node['sendgrid_mysql']['logdir']}/#{node['hostname']}.log"
  }
}
