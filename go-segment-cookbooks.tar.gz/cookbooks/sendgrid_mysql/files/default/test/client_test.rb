describe_recipe 'sendgrid_mysql::client' do

  describe 'Percona MySQL client' do

    it 'is installed' do
      assert_sh 'mysql --help | grep Percona'
    end

  end

end
