describe_recipe 'sendgrid_mysql::server' do

  describe 'Percona MySQL server' do

    it 'is installed' do
      assert_sh 'mysqld --version | grep Percona'
    end

    it 'is running' do
      assert_sh "echo 'show databases' | mysql | grep mysql"
    end

  end

end
