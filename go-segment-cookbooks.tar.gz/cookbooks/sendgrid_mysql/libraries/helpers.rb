class Chef
  module SendgridMySQL
    module Helpers
      # Converts a hash to an ini file
      # @param [Hash] hash the input hash
      # @return [String] environment variables
      def hash_to_ini(hash)
        ini = ''
        hash.each do |section, options|
          ini += "[#{section}]\n"
          options.each do |name, value|
            ini += "#{name}=#{value}\n"
          end
          ini += "\n"
        end
        ini
      end
    end
  end
end
