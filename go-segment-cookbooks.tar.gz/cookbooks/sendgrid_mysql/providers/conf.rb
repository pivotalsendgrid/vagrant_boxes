include Chef::SendgridMySQL::Helpers

use_inline_resources

action :create do

  content = send("hash_to_ini".to_sym, new_resource.options)

  file new_resource.path do
    content content
    mode new_resource.mode
    owner new_resource.owner
    group new_resource.group
  end
end

action :delete do
  file conf_path do
    action :delete
  end
end
