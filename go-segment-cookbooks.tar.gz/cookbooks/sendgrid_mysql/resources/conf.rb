actions :create, :delete
default_action :create

attribute :path, :kind_of => String, :name_attribute => true
attribute :options, :kind_of => Hash, :default => {}
attribute :mode, :kind_of => [Integer, String], :default => 00644
attribute :owner, :kind_of => String
attribute :group, :kind_of => String
