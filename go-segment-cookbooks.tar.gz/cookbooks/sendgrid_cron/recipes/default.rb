#
# Cookbook Name:: sendgrid_cron
# Recipe:: default
#
# Copyright (C) 2013 SendGrid
#
# All rights reserved - Do Not Redistribute
#
include_recipe 'cron'

# Ensure that cron.hourly runs at 50 minutes after the hour. We have Nagios
# alerts that expect some things to be done around this time (e.g. the
# logrotate script that uploads /var/log/sendgrid.log to S3).
case node['platform']
when 'centos'
  template '/etc/cron.d/0hourly' do
    source '0hourly.erb'
    mode 00644
    only_if { node['platform'] == 'centos' }
  end
when 'ubuntu'
  template '/etc/crontab' do
    source 'crontab.erb'
    mode 00644
  end
end
