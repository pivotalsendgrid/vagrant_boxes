# sendgrid_cron cookbook

This cookbook installs and configures cron.

# Usage

Just add the default recipe to your run list.
