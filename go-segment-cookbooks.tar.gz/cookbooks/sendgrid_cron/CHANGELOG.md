# CHANGELOG

## 0.1.1

- Relax dependencies

## 0.1.0

- Initial release
