actions :create, :delete
default_action :create

attribute :name, :kind_of => String, :name_attribute => true
attribute :cookbook, :kind_of => String
attribute :source, :kind_of => String, :default => 'monit.conf.erb'
attribute :variables, :kind_of => Hash
