describe_recipe 'monit::default' do

  it 'enables the service' do
    service('monit').must_be_enabled
  end

  it 'starts the service' do
    service('monit').must_be_running
  end

  it 'enables http for localhost' do
    assert_sh('monit status')
  end

end
