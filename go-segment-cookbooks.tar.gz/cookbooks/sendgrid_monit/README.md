# sendgrid_application_monit cookbook

This cookbook manages [monit](http://mmonit.com/monit/).

# Usage

## Recipes

- **default**: Installs monit and configures global/default settings.

## Resources

### sendgrid_monit_d

This resource manages a configuration file under `/etc/monit.d/` and
automatically restarts monit on configuration updates.

**requires default recipe**

- **name**: The name of the config (name_attribute)
- **cookbook**: The cookbook that contains the source template. It defaults to
the caller's cookbook.
- **source**: The source template (default: monit.conf.erb)
- **variables**: A hash of variable names and values to render into the
template (default: nil)
- **action**: `:create` or `:delete`

#### Example

    sendgrid_monit_d 'example' do
      variables({
        :foo => 'foo',
        :bar => 'bar'
      })
    end
