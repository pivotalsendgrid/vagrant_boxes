# CHAGELOG

## 1.1.0

- Updates for yum cookbook 3.x

## 1.0.1
- Remove the default monit email notification.

## 1.0.0

- Add `sendgrid_monit_d` LWRP
- Update documentation

## 0.1.3

- Fix email alerts

## 0.1.2

- Make mailserver configurable

## 0.1.1

- Add `cookbook` option to `conf` LWRP
- Reduce start delay to 60

## 0.1.0

- Initial release
