# Note: This provider does not use use_inline_resources because it prevents us
# from notifying service[monit]

action :create do

  template "/etc/monit.d/#{new_resource.name}" do
    cookbook new_resource.cookbook
    source new_resource.source
    variables new_resource.variables
    mode 00600
    notifies :restart, 'service[monit]'
  end
  new_resource.updated_by_last_action(false)

end

action :delete do

  file "/etc/monit.d/#{new_resource.name}" do
    action :delete
    notifies :restart, 'service[monit]'
  end
  new_resource.updated_by_last_action(false)

end
