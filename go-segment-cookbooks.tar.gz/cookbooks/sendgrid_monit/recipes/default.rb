#
# Cookbook Name:: sendgrid_monit
# Recipe:: default
#
# Copyright (C) 2013 SendGrid
#
# All rights reserved - Do Not Redistribute
#
include_recipe 'yum-epel'

package 'monit'

# Remove default logging config
file '/etc/monit.d/logging' do
  action :delete
  notifies :restart, 'service[monit]'
end

template '/etc/monit.conf' do
  source 'monit.conf.erb'
  mode 00600
  notifies :restart, 'service[monit]'
end

service 'monit' do
  action :enable
end
