#
# Cookbook Name:: sendgrid_monit
# Recipe:: test
#
# Copyright (C) 2013 SendGrid
#
# All rights reserved - Do Not Redistribute
#
include_recipe 'sendgrid_monit'

sendgrid_monit_d 'test' do
  source 'test.conf.erb'
  variables({
    :name => 'monit'
  })
end
