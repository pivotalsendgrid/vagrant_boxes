#!/usr/bin/env ruby
#
# Check Elastic Search index on host:port
# This plugin checks if the following conditions are met:
# 1. there is only one index that is current
# 2. the current index is searchable
# 3. the index that is current is the highest numerical value
#
require 'rubygems' if RUBY_VERSION < '1.9.0'
require 'sensu-plugin/check/cli'
require 'rest-client'
require 'json'

class CheckESIndex < Sensu::Plugin::Check::CLI

  option :hostname,
    :short => '-h HOST',
    :long => '--hostname HOST',
    :description => 'Target hostname to check',
    :default => 'localhost'

  option :port,
    :short => '-p PORT',
    :long => '--port PORT',
    :description => 'Target port of hostname to check',
    :default => 9200,
    :proc => proc { |a| a.to_i }

  def is_searchable(index)
    searchable_alias = get_es_resource('/_cat/aliases/searchable2?format=json')

    arr = Array.new
    searchable_alias.each { |i| arr << i["index"].to_i }

    return arr.include? index
  end

  def get_es_resource(resource)
    begin
      r = RestClient::Resource.new("http://#{config[:hostname]}:#{config[:port]}/#{resource}", :timeout => 45)
      JSON.parse(r.get)
    rescue Errno::ECONNREFUSED
      warning 'Connection refused'
    rescue RestClient::RequestTimeout
      warning 'Connection timed out'
    end
  end

  def get_es_version
    info = get_es_resource('/')
    info['version']['number']
  end

  def is_master
    if Gem::Version.new(get_es_version) >= Gem::Version.new('1.0.0')
      master = get_es_resource('_cluster/state/master_node')['master_node']
      local = get_es_resource('/_nodes/_local')
    else
      master = get_es_resource('/_cluster/state?filter_routing_table=true&filter_metadata=true&filter_indices=true')['master_node']
      local = get_es_resource('/_cluster/nodes/_local')
    end
    local['nodes'].keys.first == master
  end

  def run

    if is_master
      # 1. Check if there is only one index that is current
      current_alias = get_es_resource('/_cat/aliases/current?format=json')

      critical "There are > 1 current indices" if current_alias.count > 1
      critical "There is no current index" if current_alias.count < 1

      # 2. Check if the current index is searchable
      current_index = current_alias[0]["index"].to_i

      critical "The current index is not searchable" unless is_searchable(current_index)

      # 3. Check if the index that is current is the highest numerical value
      arr = Array.new
      (get_es_resource('/_cat/indices?format=json')).each { |i| arr << i["index"].to_i }
      latest_index = arr.max

      critical "The index that is 'current' is not the latest index" if latest_index != current_index

      # EXIT with OK message
      ok "Index is good"
    else
      ok "Not the master"
    end

  end

end
