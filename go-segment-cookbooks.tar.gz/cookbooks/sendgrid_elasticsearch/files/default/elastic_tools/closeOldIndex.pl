#!/opt/perl/bin/perl

use ElasticSearch;
use Data::Dumper;

use strict;

my $host="elastic-controller.sendgrid.net";
my $e;
my $cluster_status;

my $alias;
my @time = localtime();
#print $daystamp; 

eval
{
  $e= ElasticSearch->new(
                servers=> "$host".':9200',
                transport=>'httplite'
                );
  $alias= $e->get_aliases(index=>'searchable2');

  #print Dumper($alias);

  $e->cluster_health( wait_for_status => 'green');


my @searchable2 = sort  keys %{$alias};

print Dumper(@searchable2);

  if ( $#searchable2 >= 7 )
  {
    print $searchable2[0]."\n";
    $e->aliases( actions =>[
       {remove => {index => $searchable2[0], alias =>"searchable2"}}]);
    $e->close_index(index => $searchable2[0]);
    #$e->delete_index(index => $searchable2[0]);

  }

 

} or die "$@\n";

