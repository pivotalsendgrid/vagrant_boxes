#!/bin/sh
for index in `ESIndex | fgrep -v '*' | grep ^201 | awk {'print $1'}`; do
    if [[ `echo $index | cut -c 1-8` -lt `date --date="-30days" +%Y%m%d` ]]; then
      echo $index
      ESIndex -i $index -r 
    fi
done
