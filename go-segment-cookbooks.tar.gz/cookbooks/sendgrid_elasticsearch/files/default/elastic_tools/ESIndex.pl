#!/usr/bin/perl -I /opt/perl/lib/site_perl/5.10.1

use ElasticSearch;
use Data::Dumper;
use Getopt::Long;
use Text::Table;
use IO::Handle;

use strict;

my $host="localhost";
my $e;
my $cluster_status;

my $index = 0 ;
my $close_index=0;
my $update_index=0;
my $remove=0;
my $help=0;

GetOptions('index=s' => \$index,
           'close!' => \$close_index,
           'divisor=i' => \$update_index,
           'remove!' => \$remove,
           'help!' => \$help);

if ($help)
{
  print <<EOF;
ESIndex.pl -display & manipulate elastic search settings. By default displays indexes.
-i :perform some operation on this index
-c :close the index
-d n :increase the index divisor to the number "n". should generally only be run if the cluser is green.
-r :remove an index
-h :display this message.
EOF
  exit;
}
eval
{
  $e= ElasticSearch->new(
                servers=> "$host".':9200',
                transport=>'httplite'
                );
  #print Dumper($alias);

 # $e->trace_calls(1);

  if ($index)
  {
    if ($close_index)
    {
      $e->aliases( actions =>[
	  {remove => {index => $index, alias =>"searchable2"}}
	  ]); 
      $e->close_index( index=> $index) if $close_index;
    }
    elsif ($update_index)
    {
      $e->update_index_settings(
          index=> $index,
          settings => { term_index_divisor => $update_index});

    }
    elsif ($remove)
    {
      my $aliases= $e->get_aliases();
      #print Dumper($aliases);
      die "cowardly refusing to delete searchable index\n" if exists $aliases->{$index}->{'aliases'}->{"searchable2"};  
      $e->delete_index( index=> $index);
    }
       
  }
  else
  {
    my $tb = Text::Table->new("index",\' | ',"divisor",\' | ',"open",\' | ', "current",\' | ', "searchable");


    my $aliases = $e->get_aliases();
    my $current_index =   each %{$e->get_aliases(index=>'current')};
    my $index_setting = $e->index_settings( index=> $aliases->{searchable2});
    my $status = $e->index_status();
    #print Dumper($status->{'indices'}->{2012011103});
    foreach $index (sort keys %{$aliases})
    {
      my $isCurrent='';
      $isCurrent='*' if $index eq $current_index;
      my $isSearchable='';
      $isSearchable="*" if exists $aliases->{$index}->{aliases}->{searchable2};
      my $isOpen='';
      $isOpen='*' if exists $status->{'indices'}->{$index};
      $tb->add( $index, 
                $index_setting->{$index}->{settings}->{"index.term_index_divisor"}||1,
                $isOpen,
                $isCurrent,
                $isSearchable);
    }
    my $es_health = $e->cluster_health;
    my $total_shards = $es_health->{active_shards} + $es_health->{initializing_shards} +$es_health->{unassigned_shards};
    print "nodes: $es_health->{number_of_data_nodes} status: $es_health->{status} ". int($es_health->{active_shards}/$total_shards*100) ."% of $total_shards shards up\n";  
    print $tb;
    

  }



} or die "$@\n";

