#!/opt/perl/bin/perl

use ElasticSearch;
use Data::Dumper;

use strict;

my $host="elastic-controller.sendgrid.net";
my $e;
my $cluster_status;

my $alias;
my @time = localtime();
my $daystamp = ($time[5]+1900).sprintf('%02d',$time[4]+1).sprintf('%02d',$time[3])."01";
#print $daystamp; 

eval
{
  $e= ElasticSearch->new(
                servers=> "$host".':9200',
                transport=>'httplite'
                );
  $alias= $e->get_aliases(index=>'current');

  my $oldCurrent = each %{$alias};
  print Dumper($alias);

  $e->create_index(
		index => "$daystamp",
		settings => {
			number_of_shards =>20,
			number_of_replicas =>1,
			#"index.routing.allocation.include.tag" => "sjc",
			"index.routing.allocation.total_shards_per_node" => 2
		},
		mappings => {
			msgEvent => {
				properties => {
	                        attempt => {type=>"integer", index=>"no"},
        	                msgid => {type=>"string", index=>"not_analyzed"},
                	        queued => {type=>"long", index=>"no"},
                        	reason => {type=>"string", index=>"no"},
                        	reason_id => {type=>"string", index=>"no"},
                        	status => {type=>"string"},
                        	newsletter => {type=>"string", index=>"no"},
                        	subject => {type=>"string", index=>"no"},
                       		userid => {type=>"string", index=>"not_analyzed"},
                        	http_user_agent => {type=>"string", index=>"no"},
                        	from => {type=>"multi_field",
                                	fields=> {
                                        	from_parts=>{type=>"string",analyzer=>"email"},
                                        	from_full=>{type=>"string",index=>"not_analyzed"}
                                		}
                                	},
                        	type => {type=>"string"},
                        	http_browser_os => {type=>"string", index=>"no"},
                        	ip => {type=>"ip", index=>"no"},
                        	category => {type=>"string", index=>"not_analyzed"},
                        	newsletter_id => {type=>"string", index=>"no"},
                        	processed => {type=>"long"},
                        	newsletter_user_list_id => {type=>"string", index=>"no"},
                        	http_browser_version => {type=>"string", index=>"no"},
                        	email =>  {type=>"multi_field",
                                	fields=> {
                                        	email_parts=>{type=>"string",analyzer=>"email"},
                                        	email_full=>{type=>"string",index=>"not_analyzed"}
                                	}
                                	},
                        	event => {type=>"string"},
                        	unique_args => {type=>"object", enabled=>0},
                        	http_remote_ip => {type=>"ip", index=>"no"},
                        	http_browser => {type=>"string", index=>"no"},
                        	urlid => {type=>"string", index=>"no"},
				RawHeaders => {type=>"object", enabled=>0},
				Verdicts => {type=>"object", enabled=>0},
				ee_time => {type=>"long", index=>"no"},
				elaspsed_sec => {type=>"double", index=>"no"},
				envelopeFrom => {type=>"string", index=>"no"},
				filterd_time => {type=>"long", index=>"no"},
				http_referer => {type=>"string", index=>"no"},
				ismtpd_received => {type=>"string", index=>"no"},
				link_type=> {type=>"string", index=>"no"},
				links => {type=>"object", enabled=>0},
				recv_host => {type=>"string", index=>"no"},
				recv_msgid => {type=>"string", index=>"no"},
				recv_proto => {type=>"string", index=>"no"},
				size => {type=>"string", index=>"no"},
				"smtp-id" => {type=>"string", index=>"no"},
				status => {type=>"string", index=>"no"},
				type => {type=>"string", index=>"no"},
				url => {type=>"string", index=>"no"},
				urlId => {type=>"string", index=>"no"},
				urlOffset => {type=>"string", index=>"no"}
                        	}
			}
		}
		);
  $e->cluster_health( wait_for_status => 'green');



  $e->aliases( actions =>[
	{remove => {index => $oldCurrent, alias =>"current"}},
	{add => {index => "$daystamp", alias =>"current"}},
	{add => {index => "$daystamp", alias =>"searchable2"}}
	]); 

} or die "$@\n";

