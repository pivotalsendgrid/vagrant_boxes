#!/opt/perl/bin/perl

use ElasticSearch;
use Data::Dumper;

use strict;

my $host="10.42.81.103";
my $old_index_divisor= 4;  #only load 1/4 of old indexes in memory


my $e;

my $aliases;

eval
{
  $e= ElasticSearch->new(
                servers=> "$host".':9200',
                transport=>'httplite'
                );
  $aliases= $e->get_aliases(index=>'searchable2');
  $e->cluster_health( wait_for_status => 'green');
  
  my $index_setting = $e->index_settings( index=>  undef);
  print Dumper($aliases);
  
  #my @indexes= sort @{$aliases->{aliases}->{searchable2}};
  my @indexes = sort  keys %{$aliases};
  
  #don't modify the latest 2 indexes
  pop @indexes;
  pop @indexes;  
  my $index;
  foreach $index (@indexes)
  {
    if ($index_setting->{$index}->{settings}->{"index.term_index_divisor"} != $old_index_divisor)
    {
      #print "updating $index";
      $e->update_index_settings(
          index=> $index,
          settings => { term_index_divisor => $old_index_divisor});
      #$e->aliases( actions =>[
       #     {remove => {index => $index, alias =>"searchable2"}}
      #    ]);
      #closing/reopening index not required
      #$e->close_index( index=> $index);
      #$e->open_index( index=> $index);
      #$e->aliases( actions =>[
      #      {add => {index => $index, alias =>"searchable2"}}
      #    ]);
      last;
    }
  }
            


} or die "$@\n";
