#!/usr/bin/perl

use Nagios::Plugin;
use Data::Dumper;
use DBI;
use JSON;

use strict;


my $mysqlHost="10.8.95.126";
my $EShost= "10.42.81.103";
my $date = $ARGV[0] or die "need to pass the date to get stats for @ARGV";
my $dbh = DBI->connect("DBI:mysql:mail;host=$mysqlHost",'nagios','qljXPITHN87iZewC') || die "main db issue $mysqlHost: $!";
my $rows = $dbh->selectall_hashref("select id from user", 'id');


foreach my $userid (keys %$rows)
{
	my $results =`curl -s -XGET http://localhost:9200/searchable2/msgEvent/_search -d '{"query":{
"filtered":{
"filter":{
"bool":{
"must":[
{"term": {"date": "$date"}},
{"term": {"userid":"$userid"}}
]
}
},
"query":{
"bool":{
"minimum_number_should_match":1,
"should":[
{"term":{"event":"processed"}},
{"term":{"event":"drop"}}]}}}},
"facets" :
{ "event":{"terms" : {"field": "event"}}
},
"size":0

}'`;
	chomp $results;
	my $hash = decode_json($results);
	my $output= { 'userid' => $userid
				};
	foreach my $term (@{$hash->{"facets"}->{"event"}->{"terms"}})
	{
		$output->{$term->{"term"}} = $term->{"count"};
	}
	print encode_json($output);
	print "\n";


}
