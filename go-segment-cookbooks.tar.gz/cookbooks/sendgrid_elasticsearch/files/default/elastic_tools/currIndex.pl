#!/usr/bin/perl

use ElasticSearch;
use Data::Dumper;

use strict;

my $host="10.42.81.103";
my $e;
my $cluster_status;

my $alias;
my @time = localtime();
my $daystamp = ($time[5]+1900).sprintf('%02d',$time[4]+1).sprintf('%02d',$time[3])."03";
#print $daystamp; 

eval
{
  $e= ElasticSearch->new(
                servers=> "$host".':9200',
                transport=>'httplite'
                );
  $alias= $e->get_aliases(index=>'current');

  my $oldCurrent = each %{$alias};
  print Dumper($alias);


  $e->aliases( actions =>[
	{remove => {index => $oldCurrent, alias =>"current"}},
	{add => {index => "$daystamp", alias =>"current"}},
	{add => {index => "$daystamp", alias =>"searchable2"}}
	]); 

} or die "$@\n";

