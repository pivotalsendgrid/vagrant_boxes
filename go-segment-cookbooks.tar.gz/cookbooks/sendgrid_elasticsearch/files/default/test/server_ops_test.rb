describe_recipe 'sendgrid_elasticsearch::server_ops' do

  %w{check-es-cluster-status check-es-file-descriptors check-es-heap es-node-graphite}.each do |obj|
    describe obj do
      it 'was created' do
        file("/etc/sensu/conf.d/checks/#{obj}.json").must_exist
      end
    end
  end

end
