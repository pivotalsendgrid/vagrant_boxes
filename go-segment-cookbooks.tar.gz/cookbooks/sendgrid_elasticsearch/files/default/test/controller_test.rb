describe_recipe 'sendgrid_elasticsearch::controller' do

  %w{clean_old_indexes.sh currIndex.pl ESIndex.pl rotateIndex2.pl shrinkOldIndex.pl closeOldIndex.pl elasticStats ES_mailStats.pl rotateIndex.pl}.each do |obj|
    describe obj do
      it 'was created' do
        file("#{node['sendgrid_elasticsearch']['tools_dir']}/#{obj}").must_exist
      end
    end
  end

end
