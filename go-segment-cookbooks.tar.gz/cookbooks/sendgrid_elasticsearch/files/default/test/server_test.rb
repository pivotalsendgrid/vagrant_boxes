describe_recipe 'sendgrid_elasticsearch::server' do

  describe "ElasticSearch Service" do
    it "is running" do
      service("elasticsearch").must_be_running
    end
  end

end
