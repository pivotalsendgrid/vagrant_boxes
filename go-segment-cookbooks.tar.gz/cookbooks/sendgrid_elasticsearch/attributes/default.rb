default['sendgrid_elasticsearch']['version'] = '1.1.1-1'
default['sendgrid_elasticsearch']['jdk_version'] = '1.7.0_55-fcs'
default['sendgrid_elasticsearch']['cluster_name'] = 'default_cluster'
default['sendgrid_elasticsearch']['seeds'] = ['localhost']
default['sendgrid_elasticsearch']['heap_size'] = nil
default['sendgrid_elasticsearch']['tools_dir'] = '/usr/local/bin'
default['sendgrid_elasticsearch']['master_role'] = 'elastic_master'
default['sendgrid_elasticsearch']['master'] = true
default['sendgrid_elasticsearch']['data'] = true

default['sendgrid_elasticsearch']['sensu']['metric_scheme'] = if node['sendgrid_sensu_client']
  node['sendgrid_sensu_client']['metric_scheme']
end || "sensu.#{node.chef_environment}.#{hostname}"

default['sendgrid_elasticsearch']['graphite_output_type'] = if node['sendgrid_sensu_client']
  node['sendgrid_sensu_client']['output_type']
end || 'graphite'
