
## 0.4.0
* Added ES Index check
* Explicitly defined the data node
* Included sendgrid_application_perl to install /opt/perl

## 0.3.1
* Removed sendgrid_sensu_client from the run list because it's already included in sendgrid::server
* Added minimum_master_nodes attribute in elasticsearch.yml

## 0.3.0
* Added more tests
* Added Elastic tool scripts for the controller node(s)
* Created a new test suite
* Replaced some Sensu community plugins

## 0.2.0
* Updated base box for kitchen
* Added new attributes for elasticsearch and jdk version
* Removed /data dir
* Added auto discover seeds
* Passed in template attributes through recipe instead of calling node attributes directly
* Created a new recipe server_ops.rb
* Renamed default.rb recipe to server.rb
* Dynamically set the heap size unless manually set

## 0.1.0
* Initial public release
