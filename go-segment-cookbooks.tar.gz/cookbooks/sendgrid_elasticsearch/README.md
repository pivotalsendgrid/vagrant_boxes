# sendgrid_elasticsearch cookbook

## Requirements

## Usage

## Attributes

`default['sendgrid_elasticsearch']['version']` = the version of Elastic Search to be installed
`default['sendgrid_elasticsearch']['jdk_version']` =  the version of JDK to be installed
`default['sendgrid_elasticsearch']['cluster_name']` = the cluster name
`default['sendgrid_elasticsearch']['seeds']` = the list of seeds (master nodes that) to which all nodes in the cluster should talk to
`default['sendgrid_elasticsearch']['heap_size']` = the heap size allocated for Elastic Search. The value should be either 16 or 1 depending on `node['memory']['total']`
`default['sendgrid_elasticsearch']['tools_dir']` = the directory to store our custom Perl scripts for rotating Elastic Search indexes
`default['sendgrid_elasticsearch']['master_role']` = used for auto discovering the seeds
`default['sendgrid_elasticsearch']['master']` = marks the node as an eligible master
`default['sendgrid_elasticsearch']['data']` = marks the node as the data node
`default['sendgrid_elasticsearch']['sensu']['metric_scheme']` = the metric scheme to be displayed on Graphite

By default, both `default['sendgrid_elasticsearch']['master']` and `default['sendgrid_elasticsearch']['data']` are set to be *true*. In production, they should be separated from each other.

# Recipes

- *server*: installs and configures core Elastic Search
- *server_ops*: installs monitoring
- *controller*: installs Elastic Search tools for rotating indexes (should be included in the master nodes only)

# Author

SendGrid, Inc. (operations@sendgrid.com)
