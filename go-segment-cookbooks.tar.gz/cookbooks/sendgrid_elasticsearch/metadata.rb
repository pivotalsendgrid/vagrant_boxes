name             'sendgrid_elasticsearch'
maintainer       'SendGrid, Inc.'
maintainer_email 'operations@sendgrid.com'
license          'All rights reserved'
description      'Installs/Configures chef-elasticsearch'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.4.0'

depends          'sendgrid_package_repo', '~> 3.2'
depends          'sendgrid_sensu_client', '~> 0.12'
depends          'sendgrid_application_perl', '~> 3.1'
