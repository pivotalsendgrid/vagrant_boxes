#
# Cookbook Name:: sendgrid_elasticsearch
# Recipe:: server_ops
#
# Copyright (C) 2014 SendGrid, Inc.
# 
# All rights reserved - Do Not Redistribute
#

%w{
  sendgrid_elasticsearch::server
  sendgrid_sensu_client
}.each do |obj|
  include_recipe obj
end

# Sensu
plugins_dir = "/etc/sensu/community-plugins/plugins/elasticsearch"

sensu_check "check-es-cluster-status" do
  command "#{plugins_dir}/check-es-cluster-status.rb"
  handlers ['default']
  interval 60
  standalone true
end

sensu_check "check-es-file-descriptors" do
  command "#{plugins_dir}/check-es-file-descriptors.rb"
  handlers ['default']
  interval 60
  standalone true
end

# Set WARN and CRIT threshold and converts them from Gigabytes to bytes
heap_warn = 0.8 * node['sendgrid_elasticsearch']['heap_size'] * 1073741824
heap_crit = 0.9 * node['sendgrid_elasticsearch']['heap_size'] * 1073741824

sendgrid_plugins_dir = "/etc/sensu/sendgrid-plugins/plugins/elasticsearch"
directory sendgrid_plugins_dir

%w{check-es-heap check-es-index es-node-graphite}.each do |obj|
  cookbook_file "#{sendgrid_plugins_dir}/#{obj}.rb" do
    source "sensu_plugins/#{obj}.rb"
    mode 0755
    owner "root"
    group "root"
  end
end

sensu_check "check-es-heap" do
  command "#{sendgrid_plugins_dir}/check-es-heap.rb --warn #{heap_warn} --crit #{heap_crit}"
  handlers ['default']
  interval 60
  standalone true
end

sensu_check "check-es-index" do
  command "#{sendgrid_plugins_dir}/check-es-index.rb"
  handlers ['default']
  interval 60
  standalone true
end

sensu_check "es-node-graphite" do
  type 'metric'
  command "#{sendgrid_plugins_dir}/es-node-graphite.rb --scheme #{node['sendgrid_elasticsearch']['sensu']['metric_scheme']}.elasticsearch"
  handlers ['graphite']
  interval 10
  standalone true
  additional(:output_type => node['sendgrid_elasticsearch']['graphite_output_type'])
end
