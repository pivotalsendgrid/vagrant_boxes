#
# Cookbook Name:: sendgrid_elasticsearch
# Recipe:: server
#
# Copyright (C) 2014 SendGrid, Inc.
# 
# All rights reserved - Do Not Redistribute
#

# Allow pulling newer versions of jdk and elasticsearch RPMs from SG repos
include_recipe 'sendgrid_package_repo'

package 'jdk' do
  version node['sendgrid_elasticsearch']['jdk_version']
  notifies :restart, 'service[elasticsearch]'
end

package 'elasticsearch' do
  version node['sendgrid_elasticsearch']['version']
  notifies :restart, 'service[elasticsearch]'
end

template '/etc/security/limits.d/50-elasticsearch.conf' do
  notifies :restart, 'service[elasticsearch]'
end

# Auto discover seeds
if Chef::Config.solo
  Chef::Log.warn("This recipe uses search and Chef Solo does not support search. Using the default value for 'seeds'.")
else
  seeds = search(:node, "role:#{node['sendgrid_elasticsearch']['master_role']} AND chef_environment:#{node.chef_environment}").sort_by { |n| n.name }.collect { |n| n['ipaddress'] }
  node.default['sendgrid_elasticsearch']['seeds'] = seeds
end

template '/etc/elasticsearch/elasticsearch.yml' do
  variables({
    :hostname => node['hostname'],
    :master => node['sendgrid_elasticsearch']['master'],
    :data => node['sendgrid_elasticsearch']['data'],
    :cluster_name => node['sendgrid_elasticsearch']['cluster_name'],
    :seeds => node['sendgrid_elasticsearch']['seeds']
  })
  notifies :restart, 'service[elasticsearch]'
end

if node.default['sendgrid_elasticsearch']['heap_size'].nil?
  node.default['sendgrid_elasticsearch']['heap_size'] = /\d+/.match(@node['memory']['total'])[0].to_i > 24000000 ? 16 : 1
end

template '/etc/sysconfig/elasticsearch' do
  source 'elasticsearch-sysconfig.erb'
  variables({
    :heap_size => node['sendgrid_elasticsearch']['heap_size']
  })
  notifies :restart, 'service[elasticsearch]'
end

service 'elasticsearch' do
  action :start
end
