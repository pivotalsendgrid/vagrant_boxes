#
# Cookbook Name:: sendgrid_elasticsearch
# Recipe:: controller
#
# This recipe should be included in the run list of the controller/master servers only
#
# Copyright (C) 2014 SendGrid, Inc.
# 
# All rights reserved - Do Not Redistribute
#

include_recipe 'sendgrid_application_perl::_common'

directory node['sendgrid_elasticsearch']['tools_dir']

%w{ESIndex.pl ES_mailStats.pl clean_old_indexes.sh closeOldIndex.pl currIndex.pl elasticStats rotateIndex.pl rotateIndex2.pl shrinkOldIndex.pl}.each do |obj|
  cookbook_file "#{node['sendgrid_elasticsearch']['tools_dir']}/#{obj}" do
    source "elastic_tools/#{obj}"
    mode 0755
    owner "root"
    group "root"
  end
end

elastic_cron_log_dir = "/var/log/elastic_cron"
directory elastic_cron_log_dir

cron "ES Rotate Index" do
  minute 0
  hour 21
  command "#{node['sendgrid_elasticsearch']['tools_dir']}/rotateIndex.pl >> #{elastic_cron_log_dir}/rotateIndex.log"
end

cron "ES Close Old Index" do
  minute 0
  hour 22
  command "#{node['sendgrid_elasticsearch']['tools_dir']}/closeOldIndex.pl >> #{elastic_cron_log_dir}/closeOldIndex.log"
end

cron "ES Shrink Old Index" do
  minute 0
  hour 23
  command "#{node['sendgrid_elasticsearch']['tools_dir']}/shrinkOldIndex.pl >> #{elastic_cron_log_dir}/shrinkOldIndex.log"
end

cron "ES Clean Old Indexes" do
  minute 0
  hour 0
  command "#{node['sendgrid_elasticsearch']['tools_dir']}/clean_old_indexes.pl >> #{elastic_cron_log_dir}/clean_old_indexes.log"
end
