default['sendgrid_rsyslog']['reload_command'] = case platform
when 'ubuntu'
  '/sbin/restart rsyslog'
when 'centos'
  '/usr/bin/killall -HUP rsyslogd'
end

default['sendgrid_rsyslog']['s3_bucket'] = 'CHANGEME'
default['sendgrid_rsyslog']['s3_access_key'] = 'CHANGEME'
default['sendgrid_rsyslog']['s3_secret_key'] = 'CHANGEME'
default['sendgrid_rsyslog']['forward_local0'] = nil

# FIXME: This is a list of cookbooks which, if run on this node, mean we should
# expect important syslog messages to be sent to local0. Ideally, we would only
# list the individual application cookbooks that need this, but the base
# application cookbooks are about the best we can do at the moment.
default['sendgrid_rsyslog']['sendgrid_log_cookbooks'] = %w{
  sendgrid_application_perl
  sendgrid_application_python
}
