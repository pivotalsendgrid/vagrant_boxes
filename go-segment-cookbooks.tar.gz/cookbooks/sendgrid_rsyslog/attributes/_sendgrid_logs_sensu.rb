default['sendgrid_rsyslog']['sensu']['s3_bucket'] = 'CHANGEME'
default['sendgrid_rsyslog']['sensu']['s3_access_key'] = 'CHANGEME'
default['sendgrid_rsyslog']['sensu']['s3_secret_key'] = 'CHANGEME'
default['sendgrid_rsyslog']['sensu']['check_logs'] = %w{ 
  /var/log/sendgrid/sendgrid.log.3.gz
  /var/log/sendgrid/sendgrid.log.4.gz
  /var/log/sendgrid/sendgrid.log.5.gz
  /var/log/sendgrid/sendgrid.log.6.gz
  /var/log/sendgrid/sendgrid.log.7.gz
  /var/log/sendgrid/sendgrid.log.8.gz
}
