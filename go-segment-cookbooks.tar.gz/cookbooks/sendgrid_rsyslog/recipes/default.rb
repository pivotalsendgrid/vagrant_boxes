#
# Cookbook Name:: sendgrid_rsyslog
# Recipe:: default
#
# Copyright (C) 2013 SendGrid, Inc
#
# All rights reserved - Do Not Redistribute
#
include_recipe 'sendgrid_logrotate'

package 'rsyslog'

directory '/var/spool/rsyslog' do
  owner 'root'
  group 'adm'
  mode 00755
end

template '/etc/rsyslog.conf' do
  source 'rsyslog.conf.erb'
  mode 00644
  notifies :restart, 'service[rsyslog]', :immediately # FIXME: Immediate restart only for Chef 10
end

sendgrid_rsyslog_d 'rsyslog_stats' do
  priority 30
  source '30-rsyslog_stats.conf.erb'
end

sendgrid_rsyslog_d 'default' do
  priority 50
  source '50-default.conf.erb'
end

['syslog', 'maillog'].each do |f|
  cookbook_file "/etc/logrotate.d/#{f}" do
    source f
    mode 00644
    only_if { node['platform'] == 'centos' }
  end
end

# FIXME: If we're on Chef 10 we always include sendgrid_logs, since
# node.run_context isn't available there. Eventually, we'll want to get rid of
# this magic completely. We should make the sendgrid_logs recipe "public," and
# just include it from the other cookbooks that need it (i.e. the ones listed
# in that sendgrid_log_cookbooks attribute).
if !node.respond_to?(:run_context) || node['sendgrid_rsyslog']['sendgrid_log_cookbooks'].any? { |obj| node.run_context.cookbook_collection.keys.include?(obj) }
  include_recipe 'sendgrid_rsyslog::sendgrid_logs'
end

service 'rsyslog' do
  action [:enable, :start]
end
