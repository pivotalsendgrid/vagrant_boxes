#
# Cookbook Name:: sendgrid_rsyslog
# Recipe:: __sendgrid_logs_sensu
#
# Copyright (C) 2013 SendGrid, Inc
#
# All rights reserved - Do Not Redistribute
#

# there appears to be a build issue on nokogiri > 1.6.0 for centos 6
# this warrants more investigation, but for now we will use nokogiri 1.5.11
# aws-sdk requires nokogiri >= 1.4.4 
# nokogiri needs libxml2-devel and libxslt-devel installed
%w{ libxml2-devel libxslt-devel }.each do |pkg|
  package pkg
end

gem_package 'nokogiri' do
  version "1.5.11"
end

gem_package 'aws-sdk'

gem_package 'mixlib-shellout'

cookbook_file '/etc/sensu/plugins/check_s3.rb' do
  source 'check_s3.rb'
  mode 00755
end

template '/opt/sensu/.s3cfg' do # ~FC033
  source '.s3cfg-sensu.erb'
  mode 00600
  owner 'sensu'
  group 'sensu'
end

sensu_check 'check_sendgrid_logs' do
  # FIXME: THIS BE UGLY. DAYUM.
  command "check_s3.rb -b #{node['sendgrid_rsyslog']['sensu']['s3_bucket']} -a '#{node['sendgrid_rsyslog']['sensu']['s3_access_key']}' -s '#{node['sendgrid_rsyslog']['sensu']['s3_secret_key']}' -n #{node['fqdn'].gsub('.', '_')}.gz -f #{node['sendgrid_rsyslog']['sensu']['check_logs'].join(',')} -r"
  handlers ['default']
  interval 120
  standalone true
  additional(:occurrences => 2)
end

template '/etc/sendgrid_logs_sensu.s3cfg' do
  source '.s3cfg.erb'
  variables(
    :access_key => node['sendgrid_rsyslog']['s3_access_key'],
    :secret_key => node['sendgrid_rsyslog']['s3_secret_key']
  )
  owner 'sensu'
  mode 00600
end

file "/var/log/sendgrid_logs.s3cmd_remediated.log" do
  owner "sensu"
  group "sensu"
end

# #TODO/#FIXME: We can remove these when Chef has run everywhere
# and they don't exist anywhere any more

# the check below was called check_kamta_logs originally, a complete mistake
file '/etc/sensu/conf.d/checks/check_kamta_logs.json' do
  action :delete
  notifies :restart, 'service[sensu-client]', :delayed
end

# cleaning up the crappy old perl checker
file '/etc/sensu/plugins/check_cmp.pl' do
  action :delete
end
