#
# Cookbook Name:: sendgrid_rsyslog
# Recipe:: sendgrid_logs
#
# Copyright (C) 2013 SendGrid, Inc
#
# All rights reserved - Do Not Redistribute
#
%w{
  sendgrid_rsyslog
  sendgrid_s3tools
}.each do |obj|
  include_recipe obj
end

template '/etc/sendgrid_logs.s3cfg' do # ~FC033
  source '.s3cfg.erb'
  variables(
    :access_key => node['sendgrid_rsyslog']['s3_access_key'],
    :secret_key => node['sendgrid_rsyslog']['s3_secret_key']
  )
  owner "root"
  mode 00600
end

sendgrid_rsyslog_d 'sendgrid' do
  priority 40
  source '40-sendgrid.conf.erb'
  variables({
    :forward_local0 => node['sendgrid_rsyslog']['forward_local0']
  })
end

# sleep (in s) up to 20 minutes so we can splay out the uploads a bit
offset = (Digest::SHA1.digest(node['hostname']).unpack('L>').first % 20) * 60

template '/etc/logrotate.hourly/sendgrid_logs' do
  source 'sendgrid_logs.erb'
  variables(
    :reload_command => node['sendgrid_rsyslog']['reload_command'],
    :s3_bucket => node['sendgrid_rsyslog']['s3_bucket'],
    :offset => offset,
    :fqdn => node[:fqdn]
  )
  mode 00755
end

# make sure the sendgrid logs are world readable
directory '/var/log/sendgrid' do
  mode 0755
end

# now do it no matter what created the directory
# #FIXME awful awful awful
bash 'force_chmod_of_var_log_sendgrid' do
  user "root"
  cwd "/tmp"
  code <<-EOH
    chmod -R 755 /var/log/sendgrid
  EOH
end

# FIXME: The next 3 resources remove legacy stuff. This can be deleted once
# we know every server that uses this recipe has had a successful Chef run.
file '/etc/logrotate.hourly/sendgrid' do
  action :delete
end

file '/etc/logrotate.d/sendgrid' do
  action :delete
end

cron 'sendgrid-hourly' do
  action :delete
end
