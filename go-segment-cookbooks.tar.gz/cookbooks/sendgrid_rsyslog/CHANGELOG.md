# CHANGELOG

## 0.12.0

- Add `MsgOnlyFormat` template for SendGrid applications

## 0.11.3

- Use `use_inline_resources` in `d` LWRP on Chef 11

## 0.11.2

- Removing chef 11 syntax for now

## 0.11.1

- Use `use_inline_resources` in `d` LWRP

## 0.11.0

- Make sendgrid_logs recipe public
- Add `node['sendgrid_rsyslog']['forward_local0']` to allow forwarding of
sendgrid logs to a remote server

## 0.10.0

- Add `sendgrid_rsyslog_d` LWRP
- Update documentation

## 0.9.11

- specify nokogiri version before aws-sdk install

## 0.9.10

- version aws-sdk gem.  Breaks on nokogiri..centos how you make me cry

## 0.9.9
- Adding logstash / elasticsearch config for testing

## 0.9.8

- Make sure we are compressing all syslog and friends log files.
- Make sure that syslog and friends are rotated daily, and we keep 7.

## 0.9.6

- Create spool directory

## 0.9.5

- Give sensu its own dedicated S3cmd config.

## 0.9.4

- Migrate location of s3cfg to /etc and make it readable by Sensu.
- Make the Sensu remediation log writable.

## 0.9.3

- Fix an issue where we can't automatically remediate an older file when this hour's log has already been uploaded.
- Change where the s3cmd output is saved when remediated.
- Don't depend on hostname -f which, TIL, can sometimes be broken and return nothing.

## 0.9.2

- Fix an issue where we try to remediate a non-existent file.

## 0.9.1

- Forgot I need a gem for the check. :)

## 0.9.0

- Add remediation option to sensu check to automatically upload missing log entries.

## 0.8.2

- Update sensu log check alert to not be as sensitive to timing issues.

## 0.8.1

- Force the permissions issue.

## 0.8.0

- Stop using opscode's rsyslog cookbook.

## 0.7.4

- It's ok if the local log doesn't exist. (eg: first bootstrap)

## 0.7.3

- Begin paging on S3 logs not showing up.

## 0.7.2

- Set correct log permissions.

## 0.7.1

- Make /var/log/sendgrid world-readable.

## 0.7.0

- NEW S3 UPLOAD CHECK. _and the people rejoiced and danced and sang songs_

## 0.6.1

- Update hostname to use the FQDN instead of short hostname.

## 0.6.0

- Add meta data of the file md5sum when uploading to S3.

## 0.5.2

- I changed my mind. I want the timestamp of the file to match the name of the
  S3 file. Reverts to 0.5.0 functionality.

## 0.5.1

- Move the sleep so we are less likely to slip across hour boundaries.


## 0.5.0

- Splay uploads to S3 over 20 minutes. Alert after 30 minutes of brokenness.

## 0.4.4

- Only set up local0 syslog stuff for python and perl projects. I don't believe
it is ever needed for Ruby projects.

## 0.4.3

- Rename "check_kamta_logs"
- Fix bug in Chef 10

## 0.4.2

- Remove perl dependencies

## 0.4.1

- Fix bug where `include_recipe 'perl'` wasn't working when this cookbook was
included from other cookbooks.

## 0.4.0

- Only log to sendgrid.log when necessary
- Add monitoring for sendgrid.log

## 0.3.2

- Relax dependencies

## 0.3.0

- Move SendGrid specific logging directives to 40-sendgrid.conf
- Add logrotate scripts for /var/log/maillog and /var/log/syslog

## 0.2.3

- Specify location of .s3cfg

## 0.2.2

- Log s3 uploads for sendgrid logs

## 0.2.1

- Fix hardcoded syslog user
- Fix broken sendgrid_logs logrotate script

## 0.2.0

- Move logrotate and s3tools stuff to their own cookbooks
- Use standard OS-specific log destinations (CentOS/Ubuntu)
