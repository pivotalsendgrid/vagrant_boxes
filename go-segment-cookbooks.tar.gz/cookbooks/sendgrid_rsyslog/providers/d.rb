# Note: We redefine the syslog service so we can still notify service[rsyslog]
# when using use_inline_resources.

use_inline_resources if Chef::VERSION.split('.').first.to_i >= 11

action :create do

  service 'rsyslog'

  template "/etc/rsyslog.d/#{new_resource.priority}-#{new_resource.name}.conf" do
    cookbook new_resource.cookbook
    source new_resource.source
    variables new_resource.variables
    mode 00644
    notifies :restart, 'service[rsyslog]', :immediately # FIXME: Immediate restart only for Chef 10
  end

end

action :delete do

  service 'rsyslog'

  file "/etc/rsyslog.d/#{new_resource.priority}-#{new_resource.name}.conf" do
    action :delete
    notifies :restart, 'service[rsyslog]', :immediately # FIXME: Immediate restart only for Chef 10
  end

end
