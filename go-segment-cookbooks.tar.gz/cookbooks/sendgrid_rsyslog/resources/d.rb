actions :create, :delete
default_action :create

attribute :name, :kind_of => String, :name_attribute => true
attribute :priority, :kind_of => Integer, :default => 40
attribute :cookbook, :kind_of => String
attribute :source, :kind_of => String, :default => 'rsyslog.conf.erb'
attribute :variables, :kind_of => Hash
