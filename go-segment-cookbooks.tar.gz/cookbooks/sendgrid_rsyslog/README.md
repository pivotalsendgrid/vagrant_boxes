# sendgrid_rsyslog cookbook

This cookbook manages [rsyslog](http://www.rsyslog.com/).

# Usage

## Recipes

- **default**: Installs rsyslog and sets up global defaults
- **sendgrid_logs**: Sets up special handling of local0 messages

## Resources

### sendgrid_rsyslog_d

This resource manages a configuration file under `/etc/rsyslog.d/` and
automatically restarts rsyslog on configuration updates.

**requires default recipe**

- **name**: The name of the config (name_attribute)
- **priority**: The proiority of the configuration file (default: 40)
- **cookbook**: The cookbook that contains the source template. It defaults to
the caller's cookbook.
- **source**: The source template (default: rsyslog.conf.erb)
- **variables**: A hash of variable names and values to render into the
template (default: nil)
- **action**: `:create` or `:delete`

#### Example

    sendgrid_rsyslog_d 'example' do
      variables({
        :foo => 'foo',
        :bar => 'bar'
      })
    end
