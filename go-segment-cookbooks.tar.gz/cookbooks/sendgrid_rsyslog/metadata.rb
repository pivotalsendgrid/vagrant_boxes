name             'sendgrid_rsyslog'
maintainer       'SendGrid, Inc'
maintainer_email 'operations@sendgrid.com'
license          'All rights reserved'
description      'Installs/Configures rsyslog for SendGrid'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.12.0'

depends          'sendgrid_logrotate', '~> 0.1'
depends          'sendgrid_s3tools', '~> 0.1'
