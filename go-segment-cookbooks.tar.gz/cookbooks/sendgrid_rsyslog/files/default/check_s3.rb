#!/usr/bin/env ruby

require 'rubygems' if RUBY_VERSION < '1.9.0'
require 'sensu-plugin/check/cli'
require 'timeout'
require 'socket'
require 'aws-sdk'
require 'mixlib/shellout'

class CheckS3 < Sensu::Plugin::Check::CLI
  option :bucket,
    :short => '-b BUCKET',
    :long => '--bucket BUCKET',
    :description => 'S3 bucket to check',
    :required => true
  option :files,
    :short => '-f FILE',
    :long => '--files FILE',
    :description => 'Comma separated list of files to make sure land on S3',
    :required => true
  option :access_key,
    :short => '-a ACCESS_KEY',
    :long => '--access-key ACCESS_KEY',
    :description => 'Access key with privileges to that bucket.',
    :required => true
  option :secret_key,
    :short => '-s SECRET_KEY',
    :long => '--secret-key SECRET_KEY',
    :description => 'S3 Secret key.',
    :required => true
  option :filename,
    :short => '-n S3FILENAME',
    :long => '--name S3FILE',
    :description => 'Name of the file on S3',
    :default => "#{Socket.gethostname}.gz"
  option :hours,
    :short => '-h HOURS',
    :long => '--hours HOURS',
    :description => 'How many hours in S3 to check back for files.',
    :default => 12,
    :proc => proc { |a| a.to_i }
  option :timeout,
    :short => '-t TIMEOUT',
    :long => '--timeout TIMEOUT',
    :description => 'How long to wait for S3.',
    :default => 12,
    :proc => proc { |a| a.to_i }
  option :warning,
    :short => '-w',
    :long => '--warning',
    :description => 'Missing file is a warning, not a critical.',
    :boolean => true
  option :remediate,
    :short => '-r',
    :long => '--remediate',
    :description => 'If set, attempt to remediate by uploading missing local files to gaps in S3. (need s3 configuration)',
    :boolean => true
  option :s3conf,
    :short => '-c S3CONFIG',
    :long => '--s3-config S3CONFIG',
    :description => 'The S3 configuration file.',
    :default => '/etc/sendgrid_logs_sensu.s3cfg'
  option :verbose,
    :short => '-v',
    :long => '--verbose',
    :description => 'Verbose.',
    :default => false,
    :boolean => true

  def run

    # for scope
    fails = []

    # try remediation up to twice if necessary
    for i in 0..1

      fails = []

      bucket = get_bucket

      s3_results = get_s3_md5_sums(bucket)

      remote_checksums = s3_results['checksums']
      local_checksums = get_local_md5_sums

      local_checksums.each do |file|
        fails << file['file'] unless remote_checksums.include?(file['checksum'])
      end

      if config[:remediate] and fails.length > 0 and i == 0
        remediate(config[:bucket], fails, s3_results['missing_files'])
      else
        # we either can't remediate or don't have any failures, so no point in going again
        break
      end
    end

    if config[:warning] and fails.length > 0
      warning "These files are not on S3! #{fails.join(', ')}"
    elsif fails.length > 0
      critical "These files are not on S3! #{fails.join(', ')}"
    else
      ok "All #{local_checksums.length} files match files in S3."
    end
  end

  def remediate (bucket, local_files, remote_missing_files)
    # we want the oldest missing files to be filled in first
    local_files.reverse!

    if local_files.length > remote_missing_files.length
      raise "I can't automatically remediate because there aren't enough places to upload files in S3."
    end

    puts "Attempting to upload #{local_files.length} files in these gaps: #{remote_missing_files.join(', ')}"

    local_files.each do |file|
      destination = remote_missing_files.pop
      hash = get_md5sum(file) || next
      # FIXME DRY (duplicating functionality from sendgrid_logs logrotate script)
      cmd = "s3cmd --config=#{config[:s3conf]} put --add-header=x-amz-server-side-encryption:AES256 --add-header=x-amz-meta-sendgrid-hash:#{hash} #{file} s3://#{bucket}/#{destination} >> /var/log/sendgrid_logs.s3cmd_remediated.log"
      puts "About to execute: " + cmd if config[:verbose]
      s3cmd = Mixlib::ShellOut.new(cmd)
      s3cmd.run_command
      # raise an exception if there's an issue
      s3cmd.error!
    end
  end

  def get_bucket
    bucket = nil

    time_out("connecting to S3 and getting bucket info") do
      s3 = AWS::S3.new({
        :access_key_id => config[:access_key],
        :secret_access_key => config[:secret_key]
      })
      bucket = s3.buckets[config[:bucket]]
      unknown "Can't access bucket #{config[:bucket]}" unless bucket.exists?
    end

    bucket
  end

  def get_s3_md5_sums(bucket)
    # we're gonna check on files up to config[:hours] hours ago
    time = Time.now.utc - (60 * 60 * config[:hours])
    now = Time.now

    # to keep track of checksums on s3
    checksums = []
    # to keep track of gaps in the s3 records (for remediation)
    missing_files = []

    # loop through the last 12 hours and get an md5sum for each file from S3
    while time < Time.now
      file = "%04d/%02d/%02d/%02d/%s" % [time.year, time.month, time.day,
        time.hour, config[:filename]]

      time_out("getting S3 object info for #{file}") do
        obj = AWS::S3::S3Object.new(bucket, file)

        if obj.exists?
          head = obj.head
          md5 = head[:meta]['sendgrid-hash']
          checksums << md5
          puts "#{file} MD5s to #{md5}" if config[:verbose]
        else
          missing_files << file
          puts "#{file} doesn't exist" if config[:verbose]
        end
      end

      time += 3600
    end

    { 'checksums' => checksums, 'missing_files' => missing_files }
  end

  def get_local_md5_sums
    files = config[:files].split(',')
    checksums = []

    files.each do |f|
      checksum = get_md5sum(f) || next
      checksums << { "file" => f, "checksum" => checksum }
    end

    checksums
  end

  def get_md5sum(f)
    if File.exist?(f)
      md5 = Digest::MD5.hexdigest(File.read(f))
      return md5
    end

    return false
  end

  def time_out(activity, &block)
    begin
      Timeout.timeout(config[:timeout]) do
        yield block
      end
    rescue Timeout::Error
      unknown "Timed out while #{activity}"
    end
  end

end
