require 'minitest/spec'
require 'syslog'
#
# Cookbook Name:: sendgrid_rsyslog
# Spec:: default
#
describe_recipe 'sendgrid_rsyslog::_sendgrid_logs' do
  include MiniTest::Chef::Assertions
  include MiniTest::Chef::Context
  include MiniTest::Chef::Resources
  include Chef::Mixin::ShellOut

  # Strategy:
  # 1) log an empty message to LOCAL0.info to make sure sendgrid.log exists
  # 2) open sendgrid.log, seek to EOF
  # 3) log a specially-formatted message
  # 4) read next bunch of lines from sendgrid.log, expect to find our message
  # 5) profit
  it "must send local0 syslogs to sendgrid.log" do
    timestamp = Time.now.to_i
    filename = "/var/log/sendgrid/sendgrid.log"
    Syslog.opened? && Syslog.close
    Syslog.open("provisioning",
      Syslog::LOG_NDELAY | Syslog::LOG_PID, Syslog::LOG_LOCAL0)

    unless File.exist?(filename)
      Syslog.notice('{}')
      # Wanna make sure rsyslog has time to open the file, on the very first chef run
      sleep(1)
    end

    file(filename).must_exist

    logfile = File.open(filename, "r")
    logfile.must_be_instance_of(File)
    size = logfile.stat.size

    message = { "provision_ts" => timestamp }.to_json
    Syslog.notice(message)
    sleep(2)

    logfile.seek(size)

    lines=logfile.read(10000)
    lines.must_match(Regexp.new(Regexp.escape(message)))
  end

end
