describe_recipe 'sendgrid_rsyslog::default' do

  it "must start rsyslogd" do
    service("rsyslog").must_be_running
  end

end
