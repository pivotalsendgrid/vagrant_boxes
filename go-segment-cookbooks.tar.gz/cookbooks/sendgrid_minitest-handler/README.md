# sendgrid_minitest-handler cookbook

This cookbook is a wrapper for minitest-handler so we can workaround issues, 
and add to the default testing behavior.

# Usage

Add sendgrid_minitest-handler to your run list and it will behave like adding 
minitest-handler.

