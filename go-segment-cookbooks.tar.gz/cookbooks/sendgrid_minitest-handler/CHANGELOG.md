# CHANGELOG

## 0.2.2
- Include sendgrid_build_essential (fixes foodcritic error)

## 0.2.1
- Depend on sendgrid_build_essential instead of build-essential
