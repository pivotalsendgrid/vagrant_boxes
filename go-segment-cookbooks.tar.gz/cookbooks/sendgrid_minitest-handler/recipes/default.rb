#
# Cookbook Name:: sendgrid_minitest-handler
# Recipe:: default
#
# Copyright (C) 2013 SendGrid
#
# All rights reserved - Do Not Redistribute
#

# Set build-essential to install compile time so that we can support
# minitest-handler
node.default['build_essential']['compiletime'] = true
include_recipe 'sendgrid_build_essential'
include_recipe 'minitest-handler'
