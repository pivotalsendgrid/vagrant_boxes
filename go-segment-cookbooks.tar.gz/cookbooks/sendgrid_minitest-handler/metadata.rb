name             'sendgrid_minitest-handler'
maintainer       'SendGrid'
maintainer_email 'operations@sendgrid.com'
license          'All rights reserved'
description      'Installs/Configures sendgrid_minitest-handler'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.2.2'

depends 'sendgrid_build_essential', '~> 0.0'
depends 'minitest-handler', '~> 1.1.4'
