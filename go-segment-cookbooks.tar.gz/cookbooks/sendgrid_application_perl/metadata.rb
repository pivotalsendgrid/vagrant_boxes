name             'sendgrid_application_perl'
maintainer       'SendGrid'
maintainer_email 'operations@sendgrid.com'
license          'All rights reserved'
description      'Installs/Configures sendgrid_application_perl'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '3.1.0'

depends          'build-essential', '~> 1.4'
depends          'perl', '~> 1.2'
depends          'sendgrid_application', '~> 7.1'
