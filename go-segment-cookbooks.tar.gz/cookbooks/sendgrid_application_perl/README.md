# sendgrid_application_perl cookbook

This cookbook is used to install SendGrid's Perl applications.

# Usage

New Perl-based applications should depend on this cookbook. Just include the
appropriate recipe in your run list.
