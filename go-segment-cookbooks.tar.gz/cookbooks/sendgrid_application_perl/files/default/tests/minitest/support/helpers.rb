#
# Cookbook:: sendgrid_application_perl
#
require 'minitest/spec'

module Helpers
  module PerlModules
    require 'chef/mixin/shell_out'
    include Chef::Mixin::ShellOut
    include MiniTest::Chef::Assertions
    include MiniTest::Chef::Context
    include MiniTest::Chef::Resources

    # Confirms that the perl in /opt/perl can include a particular module.
    def assert_opt_perl_can_include(perl_module)
      perl_module = _normalize_module_name(perl_module)
      platform_include = case node['platform']
      when 'ubuntu'    then '/usr/local/share/perl/5.10.1'
      when 'centos'    then '/usr/local/share/perl5'
      end
      perltest =
        # TODO Why doesn't perl have in include for 
        # /usr/local/share/perl/{version}?  Or why does Devel::Modlist install 
        # there?
        # 
        shell_out %Q{\
        #{node['sendgrid_application_perl']['tarball']['install_dir']}/bin/perl \
        -I #{platform_include} \
        -e 'use #{perl_module};'
        }
      puts "#{perl_module} failed" unless perltest.exitstatus==0
      puts "STDERR: #{perltest.stderr}" unless perltest.stderr.empty?
      perltest.exitstatus.must_equal(0)
      perltest.stderr.must_be_empty
    end

    # Convert MONS/AnyEvent-SMTP-0.07.tar.gz  ==> AnyEvent::SMTP
    def _normalize_module_name(perl_module)
      return perl_module unless %r{/}.match(perl_module)
      # strip leading AUTHOR/
      perl_module.gsub!(%r{.*/}, '')
      # strip .tar.gz and friends
      perl_module.gsub!(%r{\.(tar\.gz|tar\.bz2|tgz|tbz)$}, '')
      # strip version number
      perl_module.gsub!(%r{-[\d.]+$}, '')
      # OK, what's left should just be FooBar-Baz-Quux
      perl_module.gsub!(/-/, '::')
      return perl_module
    end
  end
end
