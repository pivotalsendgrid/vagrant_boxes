#
# Cookbook Name:: sendgrid_application_perl
# Spec:: sendgrid_application_perl::_from_tarball
#
require File.expand_path('../support/helpers.rb', __FILE__)

describe_recipe 'sendgrid_application_perl::default' do
  include Helpers::PerlModules

  describe "perl binary" do
    it "must exist and be executable" do
      file(
        "/opt/perl/bin/perl"
      ).must_have(:mode, "755").with(:owner, "root").and(:group, "root")
    end

    it "must be the expected version" do
      perltest =
        shell_out %Q{#{node['sendgrid_application_perl']['tarball']['install_dir']}/bin/perl -v}
      perltest.exitstatus.must_equal(0)
      perltest.stderr.must_be_empty
      perltest.stdout.must_match(/This is perl, v#{node['sendgrid_application_perl']['tarball']['perl_version']}/)
    end

    # FIXME
    # it "must be able to use all the expected perl modules" do
    #   node['perl_modules']['modules'].each do |perl_module|
    #     unless node['perl_modules']['dont_test_modules'].include?(perl_module)
    #       assert_opt_perl_can_include(perl_module)
    #     end
    #   end
    # end

  end
end
