#
# Cookbook Name:: sendgrid_application_perl
#
require File.expand_path('../support/helpers.rb', __FILE__)

describe_recipe 'sendgrid_application_perl::build' do
  include Helpers::PerlModules

  describe 'Module::Build' do
    # TODO Incorporate version dependency
    it "must be installed" do
      assert_opt_perl_can_include "Module::Build"
    end
  end

  describe 'Devel::Modlist' do
    # TODO Incorporate version dependency
    it "must be installed" do
      assert_opt_perl_can_include "Devel::Modlist"
    end
  end
end
