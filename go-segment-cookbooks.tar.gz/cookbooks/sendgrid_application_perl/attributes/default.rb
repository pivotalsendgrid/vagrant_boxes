case node['platform']
when 'centos'
  default['sendgrid_application_perl']['tarball']['version'] = "centos_20140508"
  default['sendgrid_application_perl']['tarball']['checksum'] = '4022d886acd1012f0114e623cdd01864acd1910e99d6cf6854fb20570bbbfa25'
when 'ubuntu'
  default['sendgrid_application_perl']['tarball']['version'] = 'ubuntu_10_20140508'
  default['sendgrid_application_perl']['tarball']['checksum'] = 'ef1509b5129ca6c20994ffc8740372e079d0a398ee7bfe8613a795e752d1cc65'
end

default['sendgrid_application_perl']['tarball']['filename'] = "opt_perl_#{node['sendgrid_application_perl']['tarball']['version']}.tgz"
default['sendgrid_application_perl']['tarball']['source'] = "http://repo.sendgrid.net/#{node['sendgrid_application_perl']['tarball']['filename']}"
default['sendgrid_application_perl']['tarball']['tmp_path'] = "#{Chef::Config[:file_cache_path]}/#{node['sendgrid_application_perl']['tarball']['filename']}"
default['sendgrid_application_perl']['tarball']['install_dir'] = '/opt/perl'

default['sendgrid_application_perl']['tarball']['perl_version'] = '5.10.1'
