#
# Cookbook Name:: sendgrid_application_perl
# Recipe:: common
#
# Copyright (C) 2013 SendGrid
#
# All rights reserved - Do Not Redistribute
#
%w{
  perl
}.each do |obj|
  include_recipe obj
end

directory node['sendgrid_application_perl']['tarball']['install_dir'] do
  recursive true
end

tarball_path = node['sendgrid_application_perl']['tarball']['tmp_path']
remote_file tarball_path do
  source node['sendgrid_application_perl']['tarball']['source']
  checksum node['sendgrid_application_perl']['tarball']['checksum']
  mode 00644
end

execute "tar xf '#{tarball_path}'" do
  cwd "/opt"
  action :nothing
  subscribes :run, "remote_file[#{tarball_path}]", :immediately
end
