#
# Cookbook Name:: sendgrid_application_perl
# Recipe:: build
#
# Copyright (C) 2013 SendGrid
#
# All rights reserved - Do Not Redistribute
#
%w{
  sendgrid_application::deployment
  sendgrid_application_perl::_common
}.each do |obj|
  include_recipe obj
end

# Perl dependencies for running tests
modules = {
  'Module::Build' => '0.4007',
  'Devel::Modlist' => '0.801'
}
modules.each do |name, version|
  #cpan_module "#{name}::#{version}"
  cpan_module name

  # HACK On ubuntu its installing an older Module::Build, specifically without 
  # installdeps, so make sure all items we install are newest
  execute "cpanm install #{name}"
end
