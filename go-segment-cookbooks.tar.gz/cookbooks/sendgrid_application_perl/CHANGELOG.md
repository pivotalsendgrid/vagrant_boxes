# CHANGELOG

## 3.1.0

- Added XML::DOM, XML::Hash, XML::RegExp, Test::Class , Crypt::OpenSSL::RSA
- fixed archives, on repo/ops.sendgrid.net
- version bump

## 3.0.2

- Added XML::DOM, XML::Hash, XML::RegExp, Test::Class , Crypt::OpenSSL::RSA

## 3.0.1

- Update to centos_20140207

## 3.0.0

- Major change.  Adopted new sendgrid chef LWRP
- Changed recipe names to match standard
- Update dependencies 

## 2.2.0
- Bump requirement on sendgrid_application for package repo updates.

## 2.1.1
- Pickup upstream sendgrid_application bug fix

## 2.1.0

- Add build recipe for use in CI, dev, etc.
- Update references on upstream cookbooks for newer features.

## 2.0.1

- Relax dependencies

## 2.0.0

- Don't install /opt/perl dependencies

## 1.3.2

- Upgrade to version 20130927 of /opt/perl tarball

## 1.3.1

- Upgrade to version 20130920b of /opt/perl tarball

## 1.3.0

- Use Percona MySQL libraries

## 1.2.0

- Use `sendgrid_application` 6.0
- Don't install Perl modules via CPAN or packages (only use /opt/perl)

## 1.1.1

- Upgrade to version 20130823 of /opt/perl tarball

## 1.1.0

- Updates for `sendgrid_application` 5.0

## 1.0.1

- Move dependency on `sendgrid_package_repo` to `sendgrid_application`

## 1.0.0

- Update dependencies
- Update Perl modules

## 0.3.1

- Remove unnecessary mysql-client package

## 0.3.0

- Update dependencies

## 0.2.0

- Update dependencies

## 0.1.0

- Initial release
