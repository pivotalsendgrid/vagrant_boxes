class Chef
  module SendgridOhai
    module Helpers
      # TODO Consider IPv6 support, or a second method ipv6_from_interface
      def ip_from_interface(interface)
        case interface
        when /(\d+)\.(\d+)\.(\d+)\.(\d+)/ # IP address, just pass through
          interface

        when 'ipaddress' # Extract from node
          node['ipaddress']

        when 'internal_ip', 'internal_interface' # SG specialty, extract from node 'network'
          # TODO Want to refactor ohai plugin code so this library does the
          # work of finding the internal_ip and just returns it here, then the
          # plugin can call this library method for finding it
          node['network']['internal_ip']

        else
          # Translate some common names into others
          interface = case interface
          when 'localhost'  then 'lo'
          else              interface
          end

          # Extract from node 'network/interfaces', need to search through
          # addresses to find first one with family 'inet'
          interface_config = node['network']['interfaces'][interface]
          Chef::Application.fatal!("Cannot find interface with name '#{interface}'!") unless interface_config
          addresses = interface_config['addresses'].map do |address, config|
            # TODO Is this the adequate test here?
            config['family'] == 'inet' ? address : nil
          end.compact
          Chef::Application.fatal!("Cannot find 'inet' address for '#{interface}'!") unless addresses.length > 0
          Chef::Log.warn("Found multiple 'inet' addresses for '#{interface}', returning first.") if addresses.length > 1
          addresses.first
        end
      end
    end
  end
end
