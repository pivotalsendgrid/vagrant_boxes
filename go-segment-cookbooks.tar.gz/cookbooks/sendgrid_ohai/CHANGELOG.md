# CHANGELOG

# 0.3.0
- Fixup error reporting on unknown interface to print out correct name.
- Add 'localhost' as valid interface to translate (same as 'lo').

# 0.2.0
- Add ip_from_interface helper to Chef::SendgridOhai::Helpers.

# 0.1.3
- Relax dependencies

# 0.1.2
- Remove minitest-handler dependency
