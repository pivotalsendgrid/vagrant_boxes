# This is solely for testing.
provides "orly"
orly "yeah, rly."
