# In San Jose (only) this will work out cabinet and RU and store it in JSON
# for future reference.

# TODO: figure out a better way of telling if we're in SJC than "we're on CentOS"
# TODO: save the cdpr output in some machine-parseable form so we only do the 60-second wait once

provides "rackinfo"
require_plugin 'platform'
require_plugin 'virtualization'

# MASSIVE CHEAT!  I couldn't think of a better way to tell if we're probably in
# SJC, and therefore it's worth taking the time to wait for CDP; I just assume
# if it's CentOS, we're in SJC.  Virtualized nodes can't do CDP tho.
if platform=="centos" and (
  virtualization.empty? ||
    virtualization[:role].nil? ||
    virtualization[:role].eql?("host")
)
  rackinfo Mash.new unless rackinfo
  state = ''
  Ohai::Log.info("Expect a delay here -- running cdpr")
  from("/usr/bin/cdpr -d eth0 -t 65").split("\n").each do |line|
    case line
    when /Device ID/
      state = 'router_name'
    when /Port ID/
      state = 'rack_unit'
    when / value:\s+(\S+)$/
      case state
      when 'router_name'
        $1.match(/sjc1-(\d+)-sw\d/)
        if $1
          cab = $1.to_i
          # map 1..10 --> 101..110 and 11..20 --> 201-210
          cab += (cab <= 10 ? 100 : 190)
          rackinfo[:cabinet] = cab
        end
      when 'rack_unit'
        # value:  GigabitEthernet1/19
        $1.match(/GigabitEthernet\d\/(\d+)/)
        rackinfo[:rack_unit] = $1.to_i if $1
      end
    end
  end
  Ohai::Log.info(
    "Found some rack info: cabinet #{rackinfo[:cabinet]} / RU #{rackinfo[:rack_unit]}"
  )
end
