provides "network/internal_interface", "network/internal_ip"
require_plugin "network"

Ohai::Log.debug("Oh hai! I'm in ur codez, lookin 4 ur internal interface")

# return first interface with an IP address in 10/8, 192.168/16, or 172.16/12
def find_internal_interface
  Ohai::Log.debug("... Ohai's find_internal_interface called")
  rfc1918 = Regexp.new('^(10|192\.168|172\.(?:1[6-9]|2[0-9]|3[0-1]))\.')
  interfaces = network["interfaces"]
  internal = nil
  interfaces.keys.sort.each do |ifname|
    # Interface has addresses, and if it has flags, flags includes "UP"
    # (vifs like eth0:1 do not have flags)
    ifhash = interfaces[ifname].to_hash
    next unless ifhash["addresses"] &&
      (!ifhash["flags"] || ifhash["flags"].include?("UP"))
    ip = begin
      # to_a needed for Ruby 1.9.x, where Hash#select returns a Hash
      ifhash["addresses"].select do |address, data|
        data["family"] == "inet"
      end.to_a[0][0]
    rescue
      nil     # Quietly skip errors, which are normally "undefined method `[]' for nil:NilClass"
    end
    if rfc1918.match(ip)
      internal = ifname
      break
    end
  end
  if internal == nil
    internal = "lo"
  end
  internal
end

# TODO: copied from before_cook/libraries/ipaddr_for.rb ... really oughta only be in one place, but where?
def ipaddr_for(if_name)
  network["interfaces"][if_name.to_s]["addresses"].select do |address, data|
    data["family"] == "inet"
  end.to_a[0][0] rescue nil
end

network Mash.new unless network
network[:interfaces] = Mash.new unless network[:interfaces]

network["internal_interface"] = find_internal_interface
network["internal_ip"] = ipaddr_for(network["internal_interface"])

Ohai::Log.info("Your internal interface is: #{network["internal_interface"]}")
Ohai::Log.info("... and internal IP is: #{network["internal_ip"]}")
network["internal_interface"]
