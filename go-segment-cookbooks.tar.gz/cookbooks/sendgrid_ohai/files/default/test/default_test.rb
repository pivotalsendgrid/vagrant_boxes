describe_recipe 'sendgrid_ohai' do

  it 'installs the internal_interface plugin' do
    refute_nil node['network']['internal_interface']
  end

  it 'installs the rackinfo plugin' do
    # FIXME: How do we test this?
  end

end
