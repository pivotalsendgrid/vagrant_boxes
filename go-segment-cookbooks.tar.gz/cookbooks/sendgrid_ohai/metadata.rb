name             "sendgrid_ohai"
maintainer       "SendGrid, Inc"
maintainer_email "operations@sendgrid.com"
license          "All rights reserved"
description      "Installs/Configures sendgrid_ohai"
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          "0.3.0"

depends          "ohai", "~> 1.1"
