#
# Cookbook Name:: sendgrid_ohai
# Recipe:: default
#
# Copyright (C) 2013 SendGrid
#
# All rights reserved - Do Not Redistribute
#
node.default['ohai']['plugins'] = { 'sendgrid_ohai' => 'ohai_plugins' }

include_recipe 'ohai'
