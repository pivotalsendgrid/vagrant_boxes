# sendgrid_ohai cookbook

# Requirements

# Usage

# Attributes

# Recipes

# Helpers

### ip_from_interface
You can pass in an IP address or an interface name (i.e. eth0, lo, etc.) and 
it will return the IP address. If sendgrid_ohai default recipe is included 
then 'internal_ip' and 'internal_interface' will both work and return the 
internal IP as defined by the SendGrid Ohai plugin.

# Author

Author:: YOUR_NAME (<YOUR_EMAIL>)
