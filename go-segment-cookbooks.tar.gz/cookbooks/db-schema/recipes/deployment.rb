#
# Cookbook Name:: db-schema
# Recipe:: deployment
#
# Copyright (C) 2013 SendGrid
#
# All rights reserved - Do Not Redistribute
#

include_recipe 'sendgrid_mysql::server'
include_recipe 'sendgrid_application_python::deployment'

sendgrid_application_package 'dbschema' do
  version node['db-schema']['deployment']['version']
end

# Initalize our integration and test data
command = 'db_repo_build --initialize-all'
# Construct DB credentials based on node settings (root is always username
# from mysql install and cookbook)
command << ' --username root'
command << " --password #{node['mysql']['server_repl_password']}" if node['mysql']['server_repl_password']

execute command
