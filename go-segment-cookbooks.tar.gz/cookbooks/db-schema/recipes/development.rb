#
# Cookbook Name:: db-schema
# Recipe:: development
#
# Copyright (C) 2013 SendGrid
#
# All rights reserved - Do Not Redistribute
#

Chef::Recipe.send(:include, Chef::SendgridApplication::Helpers)

include_recipe 'sendgrid_mysql::server'
include_recipe 'sendgrid_application_python::development'

sendgrid_application_python_development_from_scm 'db-schema' do
  repository node['db-schema']['development']['repository']
  revision node['db-schema']['development']['revision']
  virtualenv_enabled false
end

# Initalize our integration and test data
development_path = sendgrid_application_development_path('db-schema')
command = 'dbschema/db_repo_build.py --initialize-all'
# Construct DB credentials based on node settings (root is always username
# from mysql install and cookbook)
command << ' --username root'
command << " --password #{node['mysql']['server_repl_password']}" if node['mysql']['server_repl_password']

execute command do
  cwd development_path
end
