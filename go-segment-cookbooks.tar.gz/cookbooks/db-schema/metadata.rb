name             'db-schema'
maintainer       'SendGrid'
maintainer_email 'operations@sendgrid.com'
license          'All rights reserved'
description      'Installs/Configures db-schema'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '7.2.0'

depends          'database', '~> 1.4'
depends          'sendgrid_application_python', '~> 2.0'
depends          'sendgrid_mysql', '~> 2.0'
