describe_recipe 'db-schema::development' do
  # TODO We probably don't want to verify them all, that's what the script is
  # doing and we should put tests there if we care
  it "created the integration mail database" do
    assert_sh "echo 'use dev_mail' | mysql"
  end

  it "created the test mail database" do
    assert_sh "echo 'use dev_mail' | mysql"
  end
end
