describe_recipe 'db-schema::deployment' do
  it 'provides the db_repo_build bin file' do
    assert_sh "which db_repo_build"
  end

  # TODO We probably don't want to verify them all, that's what the script is
  # doing and we should put tests there if we care
  it "created the integration mail database" do
    assert_sh "echo 'use dev_mail' | mysql"
  end

  it "created the test mail database" do
    assert_sh "echo 'use dev_mail_test' | mysql"
  end
end
