# db-schema cookbook

## Recipes

The descriptions below assume you have an understanding of Chef and how
SendGrid usage of Chef generally works. If not see
[Application Cookbooks](https://wiki.sendgrid.net/display/CHEF/Cookbook+Development)
for more information before continuing.


### <a name="recipe-development"></a>development

This pulls down the db-schema repository and runs the test data initialization
script from that location. This allows development on this repo and the
application of those changes into the database. See
[db-schema](https://github.com/sendgrid/db-schema) for information on how to
use db-schema.


### <a name="recipe-deployment"></a>deployment

This installs the db-schema package and runs the test data initialization
script from the installed package.  See
[db-schema](https://github.com/sendgrid/db-schema) for information on how to
use db-schema.
