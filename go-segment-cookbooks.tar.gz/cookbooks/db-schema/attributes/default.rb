default['db-schema']['deployment']['version'] = nil
default['db-schema']['deployment']['schema_prefix'] = 'dev_'

default['db-schema']['development']['repository'] = nil
default['db-schema']['development']['revision'] = 'HEAD'
default['db-schema']['development']['schema_prefix'] = 'dev_'
