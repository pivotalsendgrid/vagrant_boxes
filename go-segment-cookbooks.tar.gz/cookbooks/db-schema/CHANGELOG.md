# CHANGELOG

## 7.2.0
- Update to sendgrid_application_python 2.X for integration into
  cerberus_development.  2.X changes will have no affect on this
  application because it is not used in production.

## 7.1.0
- Update to sendgrid_mysql 2.X cookbook to pickup percona 55
- Fixes issue with yum 3.0 cookbook upgrade

## 7.0.0
- Update to latest upstream cookbook conventions.
- Make recipes use script from db-schema for test data initialization.

## 6.0.4

- Include recipe sendgrid_application_python default recipe for default
installation.

## 6.0.3

- Fix bug introduced by updates to `sendgrid_application`

## 6.0.2

- Add locator record for PowerDNS

## 6.0.1
- Update sendgrid_application requirement to correctly setup repos for various
chef environments.

## 6.0.0
- Update Gemfile restrictions for proper test-kitchen version
- Fix tailor and foodcritic errors
- Update default LWRP and build recipe to conform to new db-schema package
conventions
- Update default recipe to consume new db-schema package

## 5.1.5

- remove minitest-handler restriction in berks

## 5.1.2

- Fix locator schema bug. In the test environment, the locator for the mail
application should be set to "mail" instead of "default."

## 5.1.1

- Fix "chef_gem 'mysql'" bug. I'm not sure why this suddenly started happening,
but the mysql gem wouldn't install unless db-schema was included after
sendgrid_mysql::ruby.

## 5.1.0

- Use `sendgrid_application` 6.0

## 5.0.3

- Fix Chef::Exceptions::ImmutableAttributeModification error in build recipe

## 5.0.2

- Update sendgrid_mysql dependency

## 5.0.0

- Updates for `sendgrid_application` 5.0
- Fix attribute names to match recipe names

## 4.0.0

- Delete _development recipe and add build recipe
- Depend on `sendgrid_mysql` instead of `sg_database`


## 3.1.0

- Use `sendgrid_application` 4.0

## 3.0.0

- Update dependencies

## 2.0.1

- Fix bug where schemas were not being built reliably

## 2.0.0

- Generate the list of schemas automatically
- Add `node['db-schema']['development']['applications_ignore']` to prevent
building some schemas
- Use 'integration' branch by default

## 1.0.1

- Change attributes to reflect renaming of Janus -> Oauth

## 1.0.0

- Change schema prefix from `smtpapi_` to `dev_`
- Update dependency on sg_database

## 0.1.2

- Bootstrap test databases

## 0.1.1

- Update dependency on `sendgrid_application` to 2.1.1

## 0.1.0

- Initial release
