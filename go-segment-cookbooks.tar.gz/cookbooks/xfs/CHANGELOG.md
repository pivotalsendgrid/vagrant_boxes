## v1.1.0:

* [COOK-2076] - Add Amazon Linux support
