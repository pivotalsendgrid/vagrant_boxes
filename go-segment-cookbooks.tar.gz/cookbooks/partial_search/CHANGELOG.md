partial_search Cookbook CHANGELOG
=================================
This file is used to list changes made in each version of the partial_search cookbook.


v1.0.8 (2014-02-25)
-------------------
- [COOK-4260] Update compatibility in README.md


v1.0.6
------
- **Hotfix** - Revert client-side caching bug


v1.0.4
------
### New Feature
- **[COOK-2584](https://tickets.opscode.com/browse/COOK-2584)** - Add client-side result cache


v1.0.2
------
### Bug

- [COOK-3164]: `partial_search` should use
  `Chef::Config[:chef_server_url]` instead of `search_url`

v1.0.0
------
- Initial release
