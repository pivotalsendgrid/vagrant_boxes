## 0.6.0 - TBD

### Non-backwards compatible changes

Redis recipe, switched to redisio cookbook. The cookbook is available
on the OpsCode community site & has better platform/release support.
