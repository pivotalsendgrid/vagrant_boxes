sensu-test Cookbook
===================

Installs a sensu stack for cookbook testing
