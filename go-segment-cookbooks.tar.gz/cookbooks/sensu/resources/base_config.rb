actions :create

def initialize(*args)
  super
  @action = :create
end
