default['sendgrid_adaptec_eventmonitor']['package']['url']    = 'http://repo.sendgrid.net'
default['sendgrid_adaptec_eventmonitor']['package']['file']   = 'EventMonitor-1.04-20859.x86_64.rpm'
default['sendgrid_adaptec_eventmonitor']['package']['sha']    = '835b947a16af3ebe53a85b2b840abd3acf286d216f728aadd9a55412e500f4e2'