name             'sendgrid_adaptec_eventmonitor'
maintainer       'SendGrid Ops'
maintainer_email 'operations@sendgrid.com'
license          'All rights reserved'
description      'Installs/Configures sendgrid_adaptec_eventmonitor'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.1.1'

depends 'sendgrid_sensu_client', '~> 0.10'