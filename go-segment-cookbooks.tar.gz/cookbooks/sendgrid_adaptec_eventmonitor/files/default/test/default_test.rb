
describe_recipe 'sendgrid_adaptec_eventmonitor::default' do
  
  # this would be the preferred test, but the init script returns 0
  # no matter what since Adaptec has apparently never heard of LSB
  #it 'starts the Adaptec EventMonitor service' do
  #  service('EventMonitorService').must_be_running
  #end

  it 'starts the Adaptec EventMonitor service' do
    # make sure it really is running, output should include 'pid' if so
    result = assert_sh('/etc/init.d/EventMonitorService status')
    assert_includes result, 'pid'
  end
 
end