#
# Cookbook Name:: sendgrid_adaptec_eventmonitor
# Recipe:: nagios
#
# Copyright (C) 2014 SendGrid Ops
# 
# All rights reserved - Do Not Redistribute
#

# Install and configure the sensu raid check for adaptec controllers

include_recipe 'sendgrid_adaptec_eventmonitor::default'

# we just install the check file... the check still needs to be configured
# in the nagios monolithic cookbook
cookbook_file '/usr/local/nagios/libexec/check_adaptec_raid.pl' do
  source 'check_adaptec_raid.pl'
  owner 'root'
  group 'root'
  mode '0755'
end
