#
# Cookbook Name:: sendgrid_adaptec_eventmonitor
# Recipe:: sensu
#
# Copyright (C) 2014 SendGrid Ops
# 
# All rights reserved - Do Not Redistribute
#

# Install and configure the sensu raid check for adaptec controllers

include_recipe 'sendgrid_adaptec_eventmonitor::default'
include_recipe 'sendgrid_sensu_client'

# sensu needs sudo privileges to run /usr/Adaptec_Event_Monitor/arcconf
cookbook_file '/etc/sensu/plugins/check_adaptec_raid.pl' do
  source 'check_adaptec_raid.pl'
  owner 'root'
  group 'root'
  mode '0755'
end

sensu_check 'check_adaptec_raid' do
  command '/etc/sensu/plugins/check_adaptec_raid.pl -p /usr/Adaptec_Event_Monitor/arcconf'
  handlers ['default']
  interval 60
  standalone true
  additional(:occurrences => 2)
end
