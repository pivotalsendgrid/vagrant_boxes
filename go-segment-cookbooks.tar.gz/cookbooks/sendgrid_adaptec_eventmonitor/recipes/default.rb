#
# Cookbook Name:: sendgrid_adaptec_eventmonitor
# Recipe:: default
#
# Copyright (C) 2014 SendGrid Ops
# 
# All rights reserved - Do Not Redistribute
#

# download file from repo for Adaptec Event Monitor service
file  = node['sendgrid_adaptec_eventmonitor']['package']['file']
url   = node['sendgrid_adaptec_eventmonitor']['package']['url']
sha   = node['sendgrid_adaptec_eventmonitor']['package']['sha']
local_file  = "#{Chef::Config['file_cache_path']}/#{file}"

execute 'install_adaptec_package' do
  command "rpm -i #{local_file}"
  creates '/etc/init.d/EventMonitorService'
  only_if do File.exist?(local_file) end
  action :nothing
end

remote_file local_file do
  source "#{url}/#{file}"
  mode 0644
  checksum sha
  notifies :run, 'execute[install_adaptec_package]', :immediately
end

service 'EventMonitorService' do
  supports :status => true, :restart => true, :reload => false
  action [:enable, :start]
  only_if do File.exist?('/etc/init.d/EventMonitorService') end
end
