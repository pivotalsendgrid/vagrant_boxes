# CHANGELOG

## 0.1.1
- Adds the nagios recipe. Due to the way our nagios works, you must configure the check to be
  run in the nagios monolithic cookbook. See related PR at https://github.com/sendgrid/sendgridnet/pull/262

## 0.1.0
- Initial release. Installs the event monitor service (::default) and the sensu monitoring (::sensu).
