# sendgrid_adaptec_eventmonitor cookbook

I install and configure the Adaptec EventMonitor service for monitoring RAID services (primarily SoftLayer hosts)

## Recipe: default

The default recipe does a simply installs and starts the Adaptec EventMonitor service. This service monitors raid and posts events to the syslog. You probably don't want the default recipe, but the sensu one, unless you really know what you're doing.

Note we install the service regardless of whether or not an Adaptec RAID array is discovered.

## Recipe: sensu
This calls the default recipe so the EventMonitor service gets installed and running, then puts a check down (check_adaptec_raid.pl) that can be used to alert if the RAID array is broken somehow.

# Important Note On Chef 10 Compatibility
So we don't have to reinvent the wheel, this cookbook will be used in Chef 10 and Chef 11. In Chef 11, we use the Sensu recipe to ensure we get alerts on raid degradation. In Chef 10, we only use the default recipe to get the EventMonitor package. All the nagios stuff related to RAID monitoring (including nrpe config) happens in the monolithic nagios cookbook in the sendgridnet repo.