# sendgrid_sysctl cookbook

This cookbook manages sysctl.

# Usage

## Recipes

- **default**: Creates `/etc/sysctl.d/`
- **test**: For testing only

## Resources

### sendgrid_sysctl_d

This resource manages a configuration file under `/etc/sysctl.d/` and
automatically applies changes on configuration updates.

**requires default recipe**

- **name**: The name of the config (name_attribute)
- **priority**: The proiority of the configuration file (default: 50)
- **cookbook**: The cookbook that contains the source template. It defaults to
the caller's cookbook.
- **source**: The source template (default: sysctl.conf.erb)
- **variables**: A hash of variable names and values to render into the
template (default: nil)
- **action**: `:create` or `:delete`

#### Example

    sendgrid_sysctl_d 'example' do
      variables({
        :foo => 'foo',
        :bar => 'bar'
      })
    end
