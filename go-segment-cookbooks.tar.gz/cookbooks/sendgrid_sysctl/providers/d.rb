use_inline_resources if Chef::VERSION.split('.').first.to_i >= 11

action :create do

  conf = "/etc/sysctl.d/#{new_resource.priority}-#{new_resource.name}.conf"

  execute "sysctl_#{new_resource.name}" do
    command "sysctl -e -p #{conf}"
    action :nothing
  end

  template conf do
    cookbook new_resource.cookbook
    source new_resource.source
    variables new_resource.variables
    mode 00644
    notifies :run, "execute[sysctl_#{new_resource.name}]"
  end

end

action :delete do

  file "/etc/sysctl.d/#{new_resource.priority}-#{new_resource.name}.conf" do
    action :delete
  end

end
