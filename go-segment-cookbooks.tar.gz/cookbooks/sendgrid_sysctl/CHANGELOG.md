# sendgrid_sysctl

## 0.1.1

- Making this chef 10 friendly

## 0.1.0

- Initial release
