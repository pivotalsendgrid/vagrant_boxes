describe_recipe 'sendgrid_sysctl::test' do

  it 'sets fs.file-max' do
    assert_equal 65535, IO.read('/proc/sys/fs/file-max').to_i
  end

end
