describe_recipe 'sendgrid_sysctl::default' do

  it 'creates the sysctl.d directory' do
    directory('/etc/sysctl.d').must_exist
  end

end
