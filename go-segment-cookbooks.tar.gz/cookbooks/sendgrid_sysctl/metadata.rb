name             'sendgrid_sysctl'
maintainer       'SendGrid'
maintainer_email 'operations@sendgrid.com'
license          'All rights reserved'
description      'Installs/Configures sendgrid_sysctl'
long_description IO.read(File.join(File.dirname(__FILE__), 'README.md'))
version          '0.1.1'

