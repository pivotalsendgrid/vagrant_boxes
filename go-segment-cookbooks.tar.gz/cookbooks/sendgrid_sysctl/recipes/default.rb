#
# Cookbook Name:: sendgrid_sysctl
# Recipe:: default
#
# Copyright (C) 2014 SendGrid
#
# All rights reserved - Do Not Redistribute
#
directory '/etc/sysctl.d' do
  mode 00755
end

sendgrid_sysctl_d 'centos' do
  priority 10
  source 'centos.conf.erb'
end

file '/etc/sysctl.conf' do
  content "# The contents of this file have been moved to /etc/sysctl.d/10-centos.conf\n"
end
