#
# Cookbook Name:: sendgrid_sysctl
# Recipe:: test
#
# Copyright (C) 2014 SendGrid
#
# All rights reserved - Do Not Redistribute
#
include_recipe 'sendgrid_sysctl'

sendgrid_sysctl_d 'test'
